#ifndef FTDIFUNCTION_H
#define FTDIFUNCTION_H

//*

/**
  * \file FTDIFunction.h
  * \author Sébastien Blessemaille
  * \version 1.0
  * \date 16 septembre 2017
  * \brief FTDI manager for communication and data acquisition
  */

#include <QObject>
#include <QDebug>
#include <QDateTime>
#include "FTDI/ftd2xx.h"
#include <QtGlobal>
#include "dataFrame.h"
#include "globalEnumatedAndExtern.h"
#include "QElapsedTimer"

/**
  * \def BAUD_RATE_9600
  * \brief preprocessor symbole for BAUD_RATE_9600
  *
  * This symbole is low comunication speed.
  */
#define BAUD_RATE_9600  9600   //  speed of the USB port transfer at 9600 bits/sec

/**
  * \def BAUD_RATE_2M
  * \brief preprocessor symbole for BAUD_RATE_2M
  *
  * This symbole is high comunication speed.
  */
#define BAUD_RATE_2M  2000000  //  speed of the USB port transfer at 2'000'000 bits/sec

/**
  * \def NB_MAX_LIVE_READING_DATA
  * \brief preprocessor symbole for NB_MAX_LIVE_READING_DATA
  *
  * This symbole is maximum saved amont of data in Byte
  */
#define NB_MAX_LIVE_READING_DATA 65536       // Byte

/**
  * \def FRAME_SIZE
  * \brief preprocessor symbole for FRAME_SIZE
  *
  * This symbole is size of the data in Byte
  */
#define FRAME_SIZE    8                     //bytes


/**
  * \def BUFFER_SIZE
  * \brief preprocessor symbole for BUFFER_SIZE
  *
  * This symbole is buffer size for the live reading data in Byte
  */
#define BUFFER_SIZE   FRAME_SIZE*NB_MAX_LIVE_READING_DATA   //bytes

class FTDIFunction : public QObject
{
    Q_OBJECT

public:
    /**
      * \fn FTDIFunction(QString name, int nbFrameReadEveryCycle, QObject *parent = 0)
      * \brief constructor for FTDIFunction
      * \param[in] name is the name of the object
      * \param[in] nbFrameReadEveryCycle is the amont of reading data every cycle
      * \param[in] parent is the parent of the new widget.
      * If it is 0 (the default), the new widget will be a window.
      * If not, it will be a child of parent, and be constrained by parent's geometry
      */
    FTDIFunction(QString name, int nbFrameReadEveryCycle, QObject *parent = 0);

    /**
      * \fn void bool FTDIconnection()
      * \brief return the status of the connection
      * \return a boolean value
      */
    bool FTDIconnection();

    /**
      * \fn int open()
      * \brief return the status of the connection as integer
      * \return a integer value, 0 is OK. (FT_OK as preprocessor symbole)
      */
    int open();

    /**
      * \fn void ReadDeviceInfo()
      * \brief read the device information
      * \return void : nothing
      */
    void ReadDeviceInfo();

    /**
      * \fn int setUSBparameter()
      * \brief Set the USB parameter.
      * \return a integer value, 0 is OK. (FT_OK as preprocessor symbole)
      */
    int setUSBparameter();

    /**
      * \fn int setBaudRate(quint64 baudRateSpeed)
      * \brief Set the baudrate speed
      * \param[in] baudRateSpeed is the value right of "Baudrate" in [bit/seconde]
      * \return a integer value, 0 is OK. (FT_OK as preprocessor symbole)
      */
    int setBaudRate(quint64 baudRateSpeed);

    /**
      * \fn int setFlowControl()
      * \brief Set the flow control.
      * \return a integer value, 0 is OK. (FT_OK as preprocessor symbole)
      */
    int setFlowControl();

    /**
      * \fn int setDataCaracteristique()
      * \brief Set the carateristics of the data transfer.
      * \return a integer value, 0 is OK. (FT_OK as preprocessor symbole)
      */
    int setDataCaracteristique();

    /**
      * \fn int setRTS()
      * \brief Switch on the RTS output of the FTDI chip.
      * \return a integer value, 0 is OK. (FT_OK as preprocessor symbole)
      */
    int setRTS();

    /**
      * \fn int resetRTS()
      * \brief Switch off the RTS output of the FTDI chip.
      * \return a integer value, 0 is OK. (FT_OK as preprocessor symbole)
      */
    int resetRTS();

    /**
      * \fn int resetdevice()
      * \brief reset the FTDI chip.
      * \return a integer value, 0 is OK. (FT_OK as preprocessor symbole)
      */
    int resetdevice();

    /**
      * \fn int freeTxRxBuffer()
      * \brief Clean the TX and RX FTDI buffers.
      * \return a integer value, 0 is OK. (FT_OK as preprocessor symbole)
      */
    int freeTxRxBuffer();

    /**
      * \fn int readDataOneChar(DWORD dwRxSize)
      * \brief Read the data from USB flow.
      * \param[in] dwRxSize is the amont of one char.
      * \return a integer value, 0 is OK. (FT_OK as preprocessor symbole)
      */
    int readDataOneChar(DWORD dwRxSize);

    /**
      * \fn int writeDataOneChar(int *data)
      * \brief Read the data from USB flow.
      * \param[in] dwRxSize is the amont of one char.
      * \return a integer value, 0 is OK. (FT_OK as preprocessor symbole)
      */
    int writeDataOneChar(int *data);

    /**
      * \fn void liveReading()
      * \brief start to read the data from USB flow.
      * \return void : nothing
      */
    void liveReading();

    /**
      * \fn sendStop()
      * \brief stop the data creation of the PIC
      * \return a integer value as acknoledgement
      */
    quint8 sendStop();

    /**
      * \fn FT_STATUS ftStatus() const
      * \brief Getter for ftStatus attribute
      * \return ftStatus as a FT_STATUS
      */
    FT_STATUS ftStatus() const;

    /**
      * \fn DWORD numDevs() const
      * \brief Getter for numDevs attribute
      * \return numDevs as a DWORD
      */
    DWORD numDevs() const;

    /**
      * \fn DWORD Flags() const
      * \brief Getter for Flags attribute
      * \return Flags as a DWORD
      */
    DWORD Flags() const;

    /**
      * \fn DWORD ID() const
      * \brief Getter for ID attribute
      * \return ID as a DWORD
      */
    DWORD ID() const;

    /**
      * \fn DWORD Type() const
      * \brief Getter for Type attribute
      * \return Type as a DWORD
      */
    DWORD Type() const;

    /**
      * \fn DWORD LocId() const
      * \brief Getter for LocId attribute
      * \return LocId as a DWORD
      */
    DWORD LocId() const;

    /**
      * \fn QString SerialNumber()
      * \brief Getter for LocId attribute
      * \return SerialNumber as a QString
      */
    QString SerialNumber();

    /**
      * \fn QString Description()
      * \brief Getter for Description attribute
      * \return Description as a QString
      */
    QString Description();

    /**
      * \fn  QVector<DataFrame>::iterator itDataFrameBufferArray() const
      * \brief iterator for the circular buffer, use to stop the reading data in the buffer
      * \return a iterator as a QVector<DataFrame>::iterator
      */
    QVector<DataFrame>::iterator itDataFrameBufferArray() const;

    /**
      * \fn  void setItDataFrameBufferArray(const QVector<DataFrame>::iterator &itDataFrameBufferArray)
      * \brief iterator for the circular buffer, use to stop the entry of data in the buffer
      * \param[in] itDataFrameBufferArray is the iterator adresse for of the reading data position
      * \return void : nothing
      */
    void setItDataFrameBufferArray(const QVector<DataFrame>::iterator &itDataFrameBufferArray);

    /**
      * \fn bool FTDI_OK() const
      * \brief Getter for FTDI_OK attribute
      * \return FTDI_OK as a boolean
      */
    bool FTDI_OK() const;

    /**
      * \fn GlobalEnumatedAndExtern::eFTDIStatePossible FTDIState() const
      * \brief Getter for FTDIState attribute
      * \return a enumarate eFTDIStatePossible
      */
    GlobalEnumatedAndExtern::eFTDIStatePossible FTDIState() const;


    /**
      * \fn  void setDataFrameVectorReccorder(QVector<DataFrame> *dataFrameVectorReccorder)
      * \brief circilar buffer for data storage
      * \param[in] dataFrameVectorReccorder is the array for data storage fixe to 65536 values
      * \return void : nothing
      */
    void setDataFrameVectorReccorder(QVector<DataFrame> *dataFrameVectorReccorder);

    /**
      * \fn DataFrame *newDataFrame() const
      * \brief Getter for newDataFrame attribute
      * \return a DataFrame
      */
    DataFrame *newDataFrame() const;

    /**
      * \fn  void setNewDataFrame(DataFrame *newDataFrame)
      * \brief Setter for newDataFrame attribute
      * \return void : nothing
      */
    void setNewDataFrame(DataFrame *newDataFrame);

    /**
      * \fn  setItConsumerAdress(const QVector<DataFrame>::iterator &itConsumerAdress)
      * \brief iterator for the circular buffer, use to stop the entry of data from this thread
      * \param[in] itConsumerAdress is the iterator adresse for of the reading data position
      * \return void : nothing
      */
    void setItConsumerAdress(const QVector<DataFrame>::iterator &itConsumerAdress);

    /**
      * \fn  setItProducer(const QVector<DataFrame>::iterator &itProducer)
      * \brief iterator for the circular buffer
      * \param[in] itProducer is the iterator on array for the saving data position
      * \return void : nothing
      */
    void setItProducer(const QVector<DataFrame>::iterator &itProducer);

private:

    //FTDI value from chip
    FT_HANDLE _ftHandle;
    FT_DEVICE _ftDevice;
    FT_STATUS _ftStatus;
    DWORD _numDevs;
    DWORD _Flags;
    DWORD _ID;
    DWORD _Type;
    DWORD _LocId;
    char _SerialNumber[16];
    char _Description[64];
    int _iport;
    int _dataSend;
    int _dataReceived;
    int _dataStart;
    int _dataStop;
    DWORD 	_dwBytesWritten;
    DWORD _dwBytesRead;

    //connection
    bool _FTDI_OK;
    quint32 _baudRateSpeed2M;
    quint16 _baudRateSpeed9600;

    //state of FTDI connection
    GlobalEnumatedAndExtern::eFTDIStatePossible _FTDIState;

    void initVariable();

    //read flow data from chips and save in buf
    unsigned char buf[BUFFER_SIZE];

    //counter for check the data is
    char counterValueHigh, counterValueLow;

    //application
    unsigned long i,j,k,l,m;
    long int counterValue, counterError, counterValueFind;
    unsigned long int trameNumberRead;
    FT_HANDLE ftHandle() const;
    void setFtHandle(const FT_HANDLE &ftHandle);

    //temporary buffer for new Datas
    DataFrame *_newDataFrame;
    QVector<DataFrame> *_dataFrameVectorReccorder;
    QVector<DataFrame>::iterator _itProducer;
    QVector<DataFrame>::iterator _itConsumerAdress;

    //number of frame reading every cycle
    int _nbFrameReadEveryCycle;

    //timer for statictics
    QElapsedTimer timerElapse;
    QElapsedTimer timerFrameCycle;
    quint64 _minTime;
    quint64 _maxTime;
    quint64 _avgTime;

signals:
    void dataFrameWasSent(int itProducerAdress);

};

#endif // FTDIFUNCTION_H
