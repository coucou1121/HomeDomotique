#include "dataFrameLiveReading.h"

DataFrameLiveReading::DataFrameLiveReading(QString name, quint32 nbFrameReadEveryCycle,  quint16 delay) :
    _delay(delay),
    _nbFrameReadEveryCycle(nbFrameReadEveryCycle),
    _dataFrameTraceBuffer(nbFrameReadEveryCycle),
    _askForStartReading(false),
    _askForStopReading(false)
  // _FTDIdevice(new FTDIFunction("FTDI Device"))
{
    this->setObjectName(name);
    moveToThread(this);
}

void DataFrameLiveReading::msleep(unsigned long msecs)
{
    QThread::msleep(msecs);
}

void DataFrameLiveReading::setDataFrameVectorReccorder(QVector<DataFrame> *dataFrameVectorReccorder)
{
    _dataFrameVectorReccorder = dataFrameVectorReccorder;
}

void DataFrameLiveReading::setItProducer(const QVector<DataFrame>::iterator &itProducer)
{
    _itProducer = itProducer;
}

void DataFrameLiveReading::setItConsumerAdress(const QVector<DataFrame>::iterator &itConsumerAdress)
{
    _itConsumerAdress = itConsumerAdress;
}

void DataFrameLiveReading::startReading()
{
    this->_askForStartReading = true;
}

void DataFrameLiveReading::stopReading()
{
    this->_askForStopReading = true;
}
FTDIFunction *DataFrameLiveReading::FTDIdevice() const
{
    return _FTDIdevice;
}

void DataFrameLiveReading::setFTDIdevice(FTDIFunction *FTDIdevice)
{
    _FTDIdevice = FTDIdevice;
}

void DataFrameLiveReading::run()
{
    static quint64 cpt = 0;
    static bool inReadingProcess = false;
    int startReadData = (int)GlobalEnumatedAndExtern::transmissionEnquiry;

    while(true)
    {

        cpt++;

        if(_askForStartReading && !inReadingProcess)
        {
            qDebug() << this->objectName() << "ask thread to start reading";

            this->_FTDIdevice->writeDataOneChar(&startReadData);
            int dataReceived = this->_FTDIdevice->readDataOneChar(1);
            if(dataReceived == (int)GlobalEnumatedAndExtern::positiveAcknoledge)
            {
                qDebug() << this->objectName() << "thread start reading";
                this->_FTDIdevice->liveReading();
                inReadingProcess = true;
            }
            _askForStartReading = false;
        }

        if(_askForStopReading)
        {
            qDebug() << this->objectName() << "thread stop reading";
            this->FTDIdevice()->sendStop();
            _askForStopReading = false;
            inReadingProcess = false;
        }

        if(inReadingProcess)
        {
            this->_FTDIdevice->liveReading();
        }
        this->msleep(_delay);
    }
}
