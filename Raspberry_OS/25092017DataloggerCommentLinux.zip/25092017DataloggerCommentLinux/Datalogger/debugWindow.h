#ifndef DEBUGWINDOW_H
#define DEBUGWINDOW_H

/**
  * \file debugWindow.h
  * \author Sébastien Blessemaille
  * \version 1.0
  * \date 17 septembre 2017
  * \brief windows for the debug menu
  */

#define RASPI 1

#include <QFrame>
#include <QDebug>
#include <QTextBlock>
#include "FTDIFunction.h"
#include "globalEnumatedAndExtern.h"
#include "dataFrame.h"


namespace Ui {
class DebugWindow;
}

class DebugWindow : public QFrame
{
    Q_OBJECT

public:
    /**
      * \fn explicit DebugWindow(QWidget *parent = 0)
      * \brief constructor for DebugWindow
      * \param[in] parent is the parent of the new widget.
      * If it is 0 (the default), the new widget will be a window.
      * If not, it will be a child of parent, and be constrained by parent's geometry
      */
    explicit DebugWindow(QWidget *parent = 0);

    /**
      * \fn  ~DebugWindow()
      * \brief destructor for DebugWindow
      */
    ~DebugWindow();

    //setter
    /**
      * \fn void setNbSavedFrame(quint64 nbSavedFrame)
      * \brief Setter for nbSavedFrame attribute
      * \param[in] nbSavedFrame is the value right of "Nb trames sauvées"
      * \return void : nothing
      */
    void setNbSavedFrame(quint64 nbSavedFrame);

    /**
      * \fn void setFrameSize(int frameSize)
      * \brief Setter for frameSize attribute
      * \param[in] frameSize is the value right of "Taille d'une trame"
      * \return void : nothing
      */
    void setFrameSize(int frameSize);

    /**
      * \fn void setBaudRateFTDI(const quint32 &baudRateFTDI)
      * \brief Setter for baudRateFTDI attribute
      * \param[in] baudRateFTDI is the value right of "Baudrate" in [bit/seconde]
      * \return void : nothing
      */
    void setBaudRateFTDI(const quint32 &baudRateFTDI);

    /**
      * \fn  void setFTDIdevice(FTDIFunction *FTDIdevice)
      * \brief Setter for FTDIdevice attribute
      * \param[in] FTDIdevice is the object fro FTDI device
      * \return void : nothing
      */
    void setFTDIdevice(FTDIFunction *FTDIdevice);

private:
    Ui::DebugWindow *ui;

    quint64 _nbSavedFrame;
    int _frameSize;
    quint32 _baudRateFTDI;

    //create the FTDI object
    FTDIFunction *_FTDIdevice;

    //creat message possible
    QMap<int, QString> _FTDIReturnMessagePossibleTxt;

    //check if FTDI device was found
    /**
      * \fn  bool _FTDIDeviceFound()
      * \brief check if the FTDI device was founed
      * \return a boolean
      */
    bool _FTDIDeviceFound();

    //read FTDI device info and display in text windows on debug menu
    /**
      * \fn  void _FTDIReadInfo()
      * \brief read FTDI device info and display in text windows on debug menu
      * \return void : nothing
      */
    void _FTDIReadInfo();

    //add text in text widget on debug windows
    /**
      * \fn  void _addTextInLabel(QString text)
      * \brief Add text in text widget on debug windows
      * \param[in] text is the text to add
      * \return void : nothing
      */
    void _addTextInLabel(QString text);

private slots:
    void on_lineEditNbSavedFrame_textChanged(const QString &arg1);
    void on_lineEditFrameSize_textChanged(const QString &arg1);
    void on_lineEditBaudrate_textChanged(const QString &arg1);

    void on_pushButtonFTDIInfo_released();
    void on_pushButtonSendStart_released();
    void on_pushButtonFTDIStopRead_released();

    void on_checkBoxEmulationMode_toggled(bool checked);

    void on_pushButtonSendChar_released();

    void on_pushButtonFTDIStartReadData_released();

    void on_pushButtonFTDIStopReadData_released();

    void on_pushButtonCleanText_released();

signals:

    //send value if the saved frame number changed
    void _nbFrameSavedChanged(quint64 _nbSavedFrame);

    //send value if the size of frame was changed
    void _frameSizeChanged(int _frameSize);

    //send value if FTDI baudrate was changed
    void _FTDIBaudrateChanged(int _frameSize);

    //reset the error in case of emulation
    void _checkBoxEmulationModeStatusWasChanged(bool checked);
};

#endif // DEBUGWINDOW_H
