#include "ledManager.h"
#include "ui_ledManager.h"

ledManager::ledManager(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::ledManager),
    _greenLedOn(new QPixmap(":/images/ledGreenOn.png")),
    _greenLedOff(new QPixmap(":/images/ledGreenOff.png")),
    _amberLedOn(new QPixmap(":/images/ledAmberOn.png")),
    _amberLedOff(new QPixmap(":/images/ledAmberOff.png")),
    _redLedOn(new QPixmap(":/images/ledRedOn.png")),
    _redLedOff(new QPixmap(":/images/ledRedOff.png")),

    _buttonIconGreenLedOn(new QIcon(*_greenLedOn)),
    _buttonIconGreenLedOff(new QIcon(*_greenLedOff)),
    _buttonIconAmberLedOn(new QIcon(*_amberLedOn)),
    _buttonIconAmberLedOff(new QIcon(*_amberLedOff)),
    _buttonIconRedLedOn(new QIcon(*_redLedOn)),
    _buttonIconRedLedOff(new QIcon(*_redLedOff)),

    _stateButtonLedGreenOn(false),
    _stateButtonLedAmberOn(false),
    _stateButtonLedRedOn(false)
{
    ui->setupUi(this);

    pinMode(LED_RED, OUTPUT);
    pinMode(LED_AMBER, OUTPUT);
    pinMode(LED_GREEN, OUTPUT);

    //set libraries for GPIO
    wiringPiSetup();

    //    _greenLedOn = new QPixmap(":/images/ledGreenOn.png");
    //   _greenLedOff = new QPixmap(":/images/ledGreenOff.png");
    //    _amberLedOn = new QPixmap(":/images/ledAmberOn.png");
    //    _amberLedOff = new QPixmap(":/images/ledAmberOff.png");
    //    _redLedOn = new QPixmap(":/images/ledRedOn.png");
    //    _redLedOff = new QPixmap(":/images/ledRedOff.png");

    //    _buttonIconGreenLedOn = new QIcon(*_greenLedOn);
    //    _buttonIconGreenLedOff = new QIcon(*_greenLedOff);
    //    _buttonIconAmberLedOn = new QIcon(*_amberLedOn);
    //    _buttonIconAmberLedOff = new QIcon(*_amberLedOff);
    //    _buttonIconRedLedOn = new QIcon(*_redLedOn);
    //    _buttonIconRedLedOff = new QIcon(*_redLedOff);

    ui->pushButtonGreenLed->setIcon(*_buttonIconGreenLedOff);
    ui->pushButtonAmberLed->setIcon(*_buttonIconAmberLedOff);
    ui->pushButtonRedLed->setIcon(*_buttonIconRedLedOff);
}

ledManager::~ledManager()
{
    delete ui;
}

void ledManager::greenLedOn()
{
    digitalWrite(LED_GREEN, HIGH);
}

void ledManager::amberLedOn()
{
    digitalWrite(LED_AMBER, HIGH);
}

void ledManager::redLedOn()
{
    digitalWrite(LED_RED, HIGH);
}

void ledManager::greenLedOff()
{
    digitalWrite(LED_GREEN, LOW);
}

void ledManager::amberLedOff()
{
    digitalWrite(LED_AMBER, LOW);
}

void ledManager::redLedOff()
{
    digitalWrite(LED_RED, LOW);
}

void ledManager::switchAllLedOn()
{
    ledManager::greenLedOn();
    ledManager::amberLedOn();
    ledManager::redLedOn();
}

void ledManager::switchAllLedOff()
{
    ledManager::greenLedOff();
    ledManager::amberLedOff();
    ledManager::redLedOff();
}

bool ledManager::greenPushButtonPressed()
{
    return (digitalRead(PUSH_BUTTON_GREEN) == 0 ? false : true);
}

bool ledManager::bluePushButtonPressed()
{
    return (digitalRead(PUSH_BUTTON_BLUE) == 0 ? false : true);
}

void ledManager::on_pushButtonAmberLed_clicked()
{
    _stateButtonLedAmberOn = _stateButtonLedAmberOn == true ? false : true;
    if(_stateButtonLedAmberOn)
    {
        ui->pushButtonAmberLed->setIcon(*_buttonIconAmberLedOn);
        ledManager::amberLedOn();
    }
    else
    {
        ui->pushButtonAmberLed->setIcon(*_buttonIconAmberLedOff);
        ledManager::amberLedOff();
    }
}

void ledManager::on_pushButtonGreenLed_clicked()
{
    _stateButtonLedGreenOn = _stateButtonLedGreenOn == true ? false : true;
    if(_stateButtonLedGreenOn)
    {
        ui->pushButtonGreenLed->setIcon(*_buttonIconGreenLedOn);
        ledManager::greenLedOn();
    }
    else
    {
        ui->pushButtonGreenLed->setIcon(*_buttonIconGreenLedOff);
        ledManager::greenLedOff();
    }
}

void ledManager::on_pushButtonRedLed_clicked()
{
    _stateButtonLedRedOn = _stateButtonLedRedOn == true ? false : true;
    if(_stateButtonLedRedOn)
    {
        ui->pushButtonRedLed->setIcon(*_buttonIconRedLedOn);
        ledManager::redLedOn();
    }
    else
    {
        ui->pushButtonRedLed->setIcon(*_buttonIconRedLedOff);
        ledManager::redLedOff();
    }
}
