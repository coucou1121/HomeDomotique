#ifndef LEDMANAGER_H
#define LEDMANAGER_H

//*

/**
  * \file ledManager.h
  * \author Sébastien Blessemaille
  * \version 1.0
  * \date 17 septembre 2017
  * \brief Management of GPIO led and button
  */

#define LED_RED 0
#define LED_AMBER 2
#define LED_GREEN 3
#define PUSH_BUTTON_BLUE 26
#define PUSH_BUTTON_GREEN 6

#include <QWidget>
#include <QPixmap>
#include <QDebug>
#include "wiringPi.h"
#include "frameThread.h"

namespace Ui {
class ledManager;
}

class ledManager : public QWidget
{
    Q_OBJECT

public:
    /**
      * \fn  explicit ledManager(QWidget *parent = 0)
      * \brief constructor for DigitalPlot
      * \param[in] parent is the parent of the new widget.
      * If it is 0 (the default), the new widget will be a window.
      * If not, it will be a child of parent, and be constrained by parent's geometry
      */
    explicit ledManager(QWidget *parent = 0);

    /**
      * \fn  ~ledManager()
      * \brief destructor for ledManager
      */
    ~ledManager();

    /**
      * \fn static void greenLedOn()
      * \brief Switch on the green led
      * \return void : nothing
      */
    static void greenLedOn();

    /**
      * \fn static void amberLedOn()
      * \brief Switch on the amber led
      * \return void : nothing
      */
    static void amberLedOn();

    /**
      * \fn static void redLedOn()
      * \brief Switch on the red led
      * \return void : nothing
      */
    static void redLedOn();

    /**
      * \fn static void greenLedOff()
      * \brief Switch off the green led
      * \return void : nothing
      */
    static void greenLedOff();

    /**
      * \fn static void amberLedOff()
      * \brief Switch off the amber led
      * \return void : nothing
      */
    static void amberLedOff();

    /**
      * \fn static void redLedOff()
      * \brief Switch off the red led
      * \return void : nothing
      */
    static void redLedOff();

    /**
      * \fn static void switchAllLedOn()
      * \brief Switch on all leds
      * \return void : nothing
      */
    static void switchAllLedOn();

    /**
      * \fn static void switchAllLedOff()
      * \brief Switch off all leds
      * \return void : nothing
      */
    static void switchAllLedOff();

    /**
      * \fn static bool greenPushButtonPressed()
      * \brief Check the green pushbutton status.
      * true if is pressed, false if is released
      * \return a boolean value
      */
    static bool greenPushButtonPressed();

    /**
      * \fn static bool bluePushButtonPressed()
      * \brief Check the blue pushbutton status.
      * true if is pressed, false if is released
      * \return a boolean value
      */
    static bool bluePushButtonPressed();

private:
    Ui::ledManager *ui;

    //logo
    QPixmap *_greenLedOn;
    QPixmap *_greenLedOff;
    QPixmap *_amberLedOn;
    QPixmap *_amberLedOff;
    QPixmap *_redLedOn;
    QPixmap *_redLedOff;

    QIcon *_buttonIconGreenLedOn;
    QIcon *_buttonIconGreenLedOff;
    QIcon *_buttonIconAmberLedOn;
    QIcon *_buttonIconAmberLedOff;
    QIcon *_buttonIconRedLedOn;
    QIcon *_buttonIconRedLedOff;

    bool _stateButtonLedGreenOn;
    bool _stateButtonLedAmberOn;
    bool _stateButtonLedRedOn;

private slots:

    void on_pushButtonAmberLed_clicked();
    void on_pushButtonGreenLed_clicked();
    void on_pushButtonRedLed_clicked();

};

#endif // LEDMANAGER_H
