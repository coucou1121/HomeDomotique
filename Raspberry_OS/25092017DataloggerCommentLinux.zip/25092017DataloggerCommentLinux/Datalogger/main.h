#ifndef MAIN_H
#define MAIN_H

/**
 * \mainpage Documentation of the Datalogger
 *
 * \section TB bachelor 2017 ISEC
 *
 * This is a logic analyseur with trigger equation, real time data acquision and real time ploting.
 * 16 digital and 4 analog channels
 *
 *
 * \author Blessemaille Sébastien
 * \version 1.0
 * \date 14.09.2017
 * \brief main file for the Datalogger
 */

/**
  * \file main.h
  * \author Sébastien Blessemaille
  * \version 1.0
  * \date 16 septembre 2017
  * \brief Main entry of application
  */

//define
#define TITLE "Datalogger"
#define VERSION "Version 1.00"

//libraries
#include <QApplication>
#include <QtWidgets>
#include <QDebug>

//s
#include "mainwindow.h"

#endif // MAIN_H
