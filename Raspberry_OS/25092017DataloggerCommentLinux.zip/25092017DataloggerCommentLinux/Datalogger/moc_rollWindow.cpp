/****************************************************************************
** Meta object code from reading C++ file 'rollWindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "rollWindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'rollWindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_RollWindow_t {
    QByteArrayData data[13];
    char stringdata[154];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_RollWindow_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_RollWindow_t qt_meta_stringdata_RollWindow = {
    {
QT_MOC_LITERAL(0, 0, 10),
QT_MOC_LITERAL(1, 11, 8),
QT_MOC_LITERAL(2, 20, 0),
QT_MOC_LITERAL(3, 21, 9),
QT_MOC_LITERAL(4, 31, 9),
QT_MOC_LITERAL(5, 41, 15),
QT_MOC_LITERAL(6, 57, 10),
QT_MOC_LITERAL(7, 68, 12),
QT_MOC_LITERAL(8, 81, 15),
QT_MOC_LITERAL(9, 97, 8),
QT_MOC_LITERAL(10, 106, 15),
QT_MOC_LITERAL(11, 122, 15),
QT_MOC_LITERAL(12, 138, 15)
    },
    "RollWindow\0addTrace\0\0enumTrace\0hideTrace\0"
    "addNewDataFrame\0DataFrame*\0newDataFrame\0"
    "setRangePlotAI1\0rangeTXT\0setRangePlotAI2\0"
    "setRangePlotAI3\0setRangePlotAI4"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_RollWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    1,   49,    2, 0x0a /* Public */,
       4,    1,   52,    2, 0x0a /* Public */,
       5,    1,   55,    2, 0x0a /* Public */,
       8,    1,   58,    2, 0x0a /* Public */,
      10,    1,   61,    2, 0x0a /* Public */,
      11,    1,   64,    2, 0x0a /* Public */,
      12,    1,   67,    2, 0x0a /* Public */,

 // slots: parameters
    QMetaType::Void, QMetaType::UChar,    3,
    QMetaType::Void, QMetaType::UChar,    3,
    QMetaType::Void, 0x80000000 | 6,    7,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void, QMetaType::QString,    9,
    QMetaType::Void, QMetaType::QString,    9,

       0        // eod
};

void RollWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        RollWindow *_t = static_cast<RollWindow *>(_o);
        switch (_id) {
        case 0: _t->addTrace((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 1: _t->hideTrace((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 2: _t->addNewDataFrame((*reinterpret_cast< DataFrame*(*)>(_a[1]))); break;
        case 3: _t->setRangePlotAI1((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 4: _t->setRangePlotAI2((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 5: _t->setRangePlotAI3((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 6: _t->setRangePlotAI4((*reinterpret_cast< QString(*)>(_a[1]))); break;
        default: ;
        }
    }
}

const QMetaObject RollWindow::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_RollWindow.data,
      qt_meta_data_RollWindow,  qt_static_metacall, 0, 0}
};


const QMetaObject *RollWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *RollWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_RollWindow.stringdata))
        return static_cast<void*>(const_cast< RollWindow*>(this));
    return QWidget::qt_metacast(_clname);
}

int RollWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 7;
    }
    return _id;
}
QT_END_MOC_NAMESPACE
