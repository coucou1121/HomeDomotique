/****************************************************************************
** Meta object code from reading C++ file 'settingChannelSelection.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "settingChannelSelection.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'settingChannelSelection.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_SettingChannelSelection_t {
    QByteArrayData data[36];
    char stringdata[601];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SettingChannelSelection_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SettingChannelSelection_t qt_meta_stringdata_SettingChannelSelection = {
    {
QT_MOC_LITERAL(0, 0, 23),
QT_MOC_LITERAL(1, 24, 12),
QT_MOC_LITERAL(2, 37, 0),
QT_MOC_LITERAL(3, 38, 12),
QT_MOC_LITERAL(4, 51, 10),
QT_MOC_LITERAL(5, 62, 10),
QT_MOC_LITERAL(6, 73, 12),
QT_MOC_LITERAL(7, 86, 13),
QT_MOC_LITERAL(8, 100, 9),
QT_MOC_LITERAL(9, 110, 9),
QT_MOC_LITERAL(10, 120, 12),
QT_MOC_LITERAL(11, 133, 21),
QT_MOC_LITERAL(12, 155, 11),
QT_MOC_LITERAL(13, 167, 14),
QT_MOC_LITERAL(14, 182, 28),
QT_MOC_LITERAL(15, 211, 22),
QT_MOC_LITERAL(16, 234, 17),
QT_MOC_LITERAL(17, 252, 17),
QT_MOC_LITERAL(18, 270, 17),
QT_MOC_LITERAL(19, 288, 17),
QT_MOC_LITERAL(20, 306, 17),
QT_MOC_LITERAL(21, 324, 17),
QT_MOC_LITERAL(22, 342, 17),
QT_MOC_LITERAL(23, 360, 17),
QT_MOC_LITERAL(24, 378, 17),
QT_MOC_LITERAL(25, 396, 18),
QT_MOC_LITERAL(26, 415, 18),
QT_MOC_LITERAL(27, 434, 18),
QT_MOC_LITERAL(28, 453, 18),
QT_MOC_LITERAL(29, 472, 18),
QT_MOC_LITERAL(30, 491, 18),
QT_MOC_LITERAL(31, 510, 18),
QT_MOC_LITERAL(32, 529, 17),
QT_MOC_LITERAL(33, 547, 17),
QT_MOC_LITERAL(34, 565, 17),
QT_MOC_LITERAL(35, 583, 17)
    },
    "SettingChannelSelection\0_btSeleccted\0"
    "\0buttonNumber\0btSelected\0_btAddList\0"
    "buttonNummer\0_btRemoveList\0_addTrace\0"
    "enumTrace\0_removeTrace\0_errorNoSelectedTrace\0"
    "errorNumber\0noSelecetTrace\0"
    "_errorNoSelectedTriggerTrace\0"
    "noSelectedTriggerTrace\0on_btDI1_released\0"
    "on_btDI2_released\0on_btDI3_released\0"
    "on_btDI4_released\0on_btDI5_released\0"
    "on_btDI6_released\0on_btDI7_released\0"
    "on_btDI8_released\0on_btDI9_released\0"
    "on_btDI10_released\0on_btDI11_released\0"
    "on_btDI12_released\0on_btDI13_released\0"
    "on_btDI14_released\0on_btDI15_released\0"
    "on_btDI16_released\0on_btAI1_released\0"
    "on_btAI2_released\0on_btAI3_released\0"
    "on_btAI4_released"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SettingChannelSelection[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      27,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       7,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    2,  149,    2, 0x06 /* Public */,
       5,    1,  154,    2, 0x06 /* Public */,
       7,    1,  157,    2, 0x06 /* Public */,
       8,    1,  160,    2, 0x06 /* Public */,
      10,    1,  163,    2, 0x06 /* Public */,
      11,    2,  166,    2, 0x06 /* Public */,
      14,    2,  171,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      16,    0,  176,    2, 0x08 /* Private */,
      17,    0,  177,    2, 0x08 /* Private */,
      18,    0,  178,    2, 0x08 /* Private */,
      19,    0,  179,    2, 0x08 /* Private */,
      20,    0,  180,    2, 0x08 /* Private */,
      21,    0,  181,    2, 0x08 /* Private */,
      22,    0,  182,    2, 0x08 /* Private */,
      23,    0,  183,    2, 0x08 /* Private */,
      24,    0,  184,    2, 0x08 /* Private */,
      25,    0,  185,    2, 0x08 /* Private */,
      26,    0,  186,    2, 0x08 /* Private */,
      27,    0,  187,    2, 0x08 /* Private */,
      28,    0,  188,    2, 0x08 /* Private */,
      29,    0,  189,    2, 0x08 /* Private */,
      30,    0,  190,    2, 0x08 /* Private */,
      31,    0,  191,    2, 0x08 /* Private */,
      32,    0,  192,    2, 0x08 /* Private */,
      33,    0,  193,    2, 0x08 /* Private */,
      34,    0,  194,    2, 0x08 /* Private */,
      35,    0,  195,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::UChar, QMetaType::Bool,    3,    4,
    QMetaType::Void, QMetaType::UChar,    6,
    QMetaType::Void, QMetaType::UChar,    6,
    QMetaType::Void, QMetaType::UChar,    9,
    QMetaType::Void, QMetaType::UChar,    9,
    QMetaType::Void, QMetaType::UChar, QMetaType::Bool,   12,   13,
    QMetaType::Void, QMetaType::UChar, QMetaType::Bool,   12,   15,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void SettingChannelSelection::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        SettingChannelSelection *_t = static_cast<SettingChannelSelection *>(_o);
        switch (_id) {
        case 0: _t->_btSeleccted((*reinterpret_cast< quint8(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 1: _t->_btAddList((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 2: _t->_btRemoveList((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 3: _t->_addTrace((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 4: _t->_removeTrace((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 5: _t->_errorNoSelectedTrace((*reinterpret_cast< quint8(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 6: _t->_errorNoSelectedTriggerTrace((*reinterpret_cast< quint8(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 7: _t->on_btDI1_released(); break;
        case 8: _t->on_btDI2_released(); break;
        case 9: _t->on_btDI3_released(); break;
        case 10: _t->on_btDI4_released(); break;
        case 11: _t->on_btDI5_released(); break;
        case 12: _t->on_btDI6_released(); break;
        case 13: _t->on_btDI7_released(); break;
        case 14: _t->on_btDI8_released(); break;
        case 15: _t->on_btDI9_released(); break;
        case 16: _t->on_btDI10_released(); break;
        case 17: _t->on_btDI11_released(); break;
        case 18: _t->on_btDI12_released(); break;
        case 19: _t->on_btDI13_released(); break;
        case 20: _t->on_btDI14_released(); break;
        case 21: _t->on_btDI15_released(); break;
        case 22: _t->on_btDI16_released(); break;
        case 23: _t->on_btAI1_released(); break;
        case 24: _t->on_btAI2_released(); break;
        case 25: _t->on_btAI3_released(); break;
        case 26: _t->on_btAI4_released(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (SettingChannelSelection::*_t)(quint8 , bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingChannelSelection::_btSeleccted)) {
                *result = 0;
            }
        }
        {
            typedef void (SettingChannelSelection::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingChannelSelection::_btAddList)) {
                *result = 1;
            }
        }
        {
            typedef void (SettingChannelSelection::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingChannelSelection::_btRemoveList)) {
                *result = 2;
            }
        }
        {
            typedef void (SettingChannelSelection::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingChannelSelection::_addTrace)) {
                *result = 3;
            }
        }
        {
            typedef void (SettingChannelSelection::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingChannelSelection::_removeTrace)) {
                *result = 4;
            }
        }
        {
            typedef void (SettingChannelSelection::*_t)(quint8 , bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingChannelSelection::_errorNoSelectedTrace)) {
                *result = 5;
            }
        }
        {
            typedef void (SettingChannelSelection::*_t)(quint8 , bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingChannelSelection::_errorNoSelectedTriggerTrace)) {
                *result = 6;
            }
        }
    }
}

const QMetaObject SettingChannelSelection::staticMetaObject = {
    { &QFrame::staticMetaObject, qt_meta_stringdata_SettingChannelSelection.data,
      qt_meta_data_SettingChannelSelection,  qt_static_metacall, 0, 0}
};


const QMetaObject *SettingChannelSelection::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SettingChannelSelection::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_SettingChannelSelection.stringdata))
        return static_cast<void*>(const_cast< SettingChannelSelection*>(this));
    return QFrame::qt_metacast(_clname);
}

int SettingChannelSelection::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QFrame::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 27)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 27;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 27)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 27;
    }
    return _id;
}

// SIGNAL 0
void SettingChannelSelection::_btSeleccted(quint8 _t1, bool _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void SettingChannelSelection::_btAddList(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void SettingChannelSelection::_btRemoveList(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void SettingChannelSelection::_addTrace(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void SettingChannelSelection::_removeTrace(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void SettingChannelSelection::_errorNoSelectedTrace(quint8 _t1, bool _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void SettingChannelSelection::_errorNoSelectedTriggerTrace(quint8 _t1, bool _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}
QT_END_MOC_NAMESPACE
