/****************************************************************************
** Meta object code from reading C++ file 'settingWindow.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.3.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "settingWindow.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'settingWindow.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.3.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
struct qt_meta_stringdata_SettingWindow_t {
    QByteArrayData data[113];
    char stringdata[3730];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SettingWindow_t, stringdata) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SettingWindow_t qt_meta_stringdata_SettingWindow = {
    {
QT_MOC_LITERAL(0, 0, 13),
QT_MOC_LITERAL(1, 14, 22),
QT_MOC_LITERAL(2, 37, 0),
QT_MOC_LITERAL(3, 38, 11),
QT_MOC_LITERAL(4, 50, 25),
QT_MOC_LITERAL(5, 76, 22),
QT_MOC_LITERAL(6, 99, 25),
QT_MOC_LITERAL(7, 125, 19),
QT_MOC_LITERAL(8, 145, 14),
QT_MOC_LITERAL(9, 160, 16),
QT_MOC_LITERAL(10, 177, 9),
QT_MOC_LITERAL(11, 187, 19),
QT_MOC_LITERAL(12, 207, 12),
QT_MOC_LITERAL(13, 220, 28),
QT_MOC_LITERAL(14, 249, 7),
QT_MOC_LITERAL(15, 257, 21),
QT_MOC_LITERAL(16, 279, 11),
QT_MOC_LITERAL(17, 291, 6),
QT_MOC_LITERAL(18, 298, 28),
QT_MOC_LITERAL(19, 327, 20),
QT_MOC_LITERAL(20, 348, 19),
QT_MOC_LITERAL(21, 368, 44),
QT_MOC_LITERAL(22, 413, 44),
QT_MOC_LITERAL(23, 458, 44),
QT_MOC_LITERAL(24, 503, 44),
QT_MOC_LITERAL(25, 548, 32),
QT_MOC_LITERAL(26, 581, 8),
QT_MOC_LITERAL(27, 590, 32),
QT_MOC_LITERAL(28, 623, 32),
QT_MOC_LITERAL(29, 656, 32),
QT_MOC_LITERAL(30, 689, 43),
QT_MOC_LITERAL(31, 733, 5),
QT_MOC_LITERAL(32, 739, 43),
QT_MOC_LITERAL(33, 783, 43),
QT_MOC_LITERAL(34, 827, 43),
QT_MOC_LITERAL(35, 871, 43),
QT_MOC_LITERAL(36, 915, 43),
QT_MOC_LITERAL(37, 959, 48),
QT_MOC_LITERAL(38, 1008, 5),
QT_MOC_LITERAL(39, 1014, 48),
QT_MOC_LITERAL(40, 1063, 48),
QT_MOC_LITERAL(41, 1112, 48),
QT_MOC_LITERAL(42, 1161, 48),
QT_MOC_LITERAL(43, 1210, 48),
QT_MOC_LITERAL(44, 1259, 39),
QT_MOC_LITERAL(45, 1299, 5),
QT_MOC_LITERAL(46, 1305, 40),
QT_MOC_LITERAL(47, 1346, 42),
QT_MOC_LITERAL(48, 1389, 43),
QT_MOC_LITERAL(49, 1433, 41),
QT_MOC_LITERAL(50, 1475, 38),
QT_MOC_LITERAL(51, 1514, 44),
QT_MOC_LITERAL(52, 1559, 29),
QT_MOC_LITERAL(53, 1589, 14),
QT_MOC_LITERAL(54, 1604, 25),
QT_MOC_LITERAL(55, 1630, 28),
QT_MOC_LITERAL(56, 1659, 34),
QT_MOC_LITERAL(57, 1694, 30),
QT_MOC_LITERAL(58, 1725, 30),
QT_MOC_LITERAL(59, 1756, 30),
QT_MOC_LITERAL(60, 1787, 30),
QT_MOC_LITERAL(61, 1818, 28),
QT_MOC_LITERAL(62, 1847, 28),
QT_MOC_LITERAL(63, 1876, 28),
QT_MOC_LITERAL(64, 1905, 28),
QT_MOC_LITERAL(65, 1934, 28),
QT_MOC_LITERAL(66, 1963, 28),
QT_MOC_LITERAL(67, 1992, 28),
QT_MOC_LITERAL(68, 2021, 28),
QT_MOC_LITERAL(69, 2050, 28),
QT_MOC_LITERAL(70, 2079, 28),
QT_MOC_LITERAL(71, 2108, 28),
QT_MOC_LITERAL(72, 2137, 28),
QT_MOC_LITERAL(73, 2166, 34),
QT_MOC_LITERAL(74, 2201, 35),
QT_MOC_LITERAL(75, 2237, 37),
QT_MOC_LITERAL(76, 2275, 38),
QT_MOC_LITERAL(77, 2314, 36),
QT_MOC_LITERAL(78, 2351, 33),
QT_MOC_LITERAL(79, 2385, 39),
QT_MOC_LITERAL(80, 2425, 38),
QT_MOC_LITERAL(81, 2464, 41),
QT_MOC_LITERAL(82, 2506, 30),
QT_MOC_LITERAL(83, 2537, 35),
QT_MOC_LITERAL(84, 2573, 29),
QT_MOC_LITERAL(85, 2603, 28),
QT_MOC_LITERAL(86, 2632, 35),
QT_MOC_LITERAL(87, 2668, 35),
QT_MOC_LITERAL(88, 2704, 35),
QT_MOC_LITERAL(89, 2740, 35),
QT_MOC_LITERAL(90, 2776, 41),
QT_MOC_LITERAL(91, 2818, 41),
QT_MOC_LITERAL(92, 2860, 41),
QT_MOC_LITERAL(93, 2902, 41),
QT_MOC_LITERAL(94, 2944, 34),
QT_MOC_LITERAL(95, 2979, 34),
QT_MOC_LITERAL(96, 3014, 34),
QT_MOC_LITERAL(97, 3049, 34),
QT_MOC_LITERAL(98, 3084, 34),
QT_MOC_LITERAL(99, 3119, 34),
QT_MOC_LITERAL(100, 3154, 39),
QT_MOC_LITERAL(101, 3194, 39),
QT_MOC_LITERAL(102, 3234, 39),
QT_MOC_LITERAL(103, 3274, 39),
QT_MOC_LITERAL(104, 3314, 39),
QT_MOC_LITERAL(105, 3354, 39),
QT_MOC_LITERAL(106, 3394, 45),
QT_MOC_LITERAL(107, 3440, 46),
QT_MOC_LITERAL(108, 3487, 48),
QT_MOC_LITERAL(109, 3536, 49),
QT_MOC_LITERAL(110, 3586, 47),
QT_MOC_LITERAL(111, 3634, 44),
QT_MOC_LITERAL(112, 3679, 50)
    },
    "SettingWindow\0_addTraceInTriggerMenu\0"
    "\0traceNumber\0_removeTraceInTriggerMenu\0"
    "_addTraceInDisplayMenu\0_removeTraceInDisplayMenu\0"
    "_nbFrameSavedChange\0nbFrameChanges\0"
    "_sizeFrameChange\0frameSize\0"
    "_FTDIBaudrateChange\0FTDIBaudrate\0"
    "_percentPreTriggerWasChanged\0percent\0"
    "_errorNoSelectedTrace\0errorNumber\0"
    "active\0_errorNoSelectedTriggerTrace\0"
    "_errorFrequencyToLow\0_errorWrongEquation\0"
    "_pushButtonRangeAI1WasChangedFromSettingMenu\0"
    "_pushButtonRangeAI2WasChangedFromSettingMenu\0"
    "_pushButtonRangeAI3WasChangedFromSettingMenu\0"
    "_pushButtonRangeAI4WasChangedFromSettingMenu\0"
    "_pushButtonRangeTXTAI1WasChanged\0"
    "rangeTXT\0_pushButtonRangeTXTAI2WasChanged\0"
    "_pushButtonRangeTXTAI3WasChanged\0"
    "_pushButtonRangeTXTAI4WasChanged\0"
    "_pushButtonEdgeDI1WasChangedFromSettingMenu\0"
    "eEdge\0_pushButtonEdgeDI2WasChangedFromSettingMenu\0"
    "_pushButtonEdgeDI3WasChangedFromSettingMenu\0"
    "_pushButtonEdgeDI4WasChangedFromSettingMenu\0"
    "_pushButtonEdgeAI1WasChangedFromSettingMenu\0"
    "_pushButtonEdgeAI2WasChangedFromSettingMenu\0"
    "_doubleSpinBoxDI1_valueWasChangedFromSettingMenu\0"
    "value\0_doubleSpinBoxDI2_valueWasChangedFromSettingMenu\0"
    "_doubleSpinBoxDI3_valueWasChangedFromSettingMenu\0"
    "_doubleSpinBoxDI4_valueWasChangedFromSettingMenu\0"
    "_doubleSpinBoxAI1_valueWasChangedFromSettingMenu\0"
    "_doubleSpinBoxAI2_valueWasChangedFromSettingMenu\0"
    "_comboBoxTopLeft_currentIndexWasChanged\0"
    "index\0_comboBoxTopRight_currentIndexWasChanged\0"
    "_comboBoxBottomLeft_currentIndexWasChanged\0"
    "_comboBoxBottomRight_currentIndexWasChanged\0"
    "_comboBoxTopMiddle_currentIndexWasChanged\0"
    "_comboBoxMiddle_currentIndexWasChanged\0"
    "_comboBoxBottomMiddle_currentIndexWasChanged\0"
    "_received_NbFrameSavedChanged\0"
    "nbFrameChanged\0_received_SizeFrameChange\0"
    "_received_FTDIBaudrateChange\0"
    "_received_percentPreTriggerChanged\0"
    "pushButtonRangeAI1_changeRange\0"
    "pushButtonRangeAI2_changeRange\0"
    "pushButtonRangeAI3_changeRange\0"
    "pushButtonRangeAI4_changeRange\0"
    "pushButtonEdgeDI1_changeEdge\0"
    "pushButtonEdgeDI2_changeEdge\0"
    "pushButtonEdgeDI3_changeEdge\0"
    "pushButtonEdgeDI4_changeEdge\0"
    "pushButtonEdgeAI1_changeEdge\0"
    "pushButtonEdgeAI2_changeEdge\0"
    "doubleSpinBoxDI1_changeValue\0"
    "doubleSpinBoxDI2_changeValue\0"
    "doubleSpinBoxDI3_changeValue\0"
    "doubleSpinBoxDI4_changeValue\0"
    "doubleSpinBoxAI1_changeValue\0"
    "doubleSpinBoxAI2_changeValue\0"
    "comboBoxTopLeft_changeCurrentIndex\0"
    "comboBoxTopRight_changeCurrentIndex\0"
    "comboBoxBottomLeft_changeCurrentIndex\0"
    "comboBoxBottomRight_changeCurrentIndex\0"
    "comboBoxTopMiddle_changeCurrentIndex\0"
    "comboBoxMiddle_changeCurrentIndex\0"
    "comboBoxBottomMiddle_changeCurrentIndex\0"
    "_received_AddTraceFromChannelSelection\0"
    "_received_RemoveTraceFromChannelSelection\0"
    "_received_errorNoSelectedTrace\0"
    "_received_errorNoSectedTriggerTrace\0"
    "_received_errorFrequencyToLow\0"
    "_received_errorWrongEquation\0"
    "_received_pushButtonRangeAI1Changed\0"
    "_received_pushButtonRangeAI2Changed\0"
    "_received_pushButtonRangeAI3Changed\0"
    "_received_pushButtonRangeAI4Changed\0"
    "_received_pushButtonRangeAI1TXTWasChanged\0"
    "_received_pushButtonRangeAI2TXTWasChanged\0"
    "_received_pushButtonRangeAI3TXTWasChanged\0"
    "_received_pushButtonRangeAI4TXTWasChanged\0"
    "_received_pushButtonEdgeDI1Changed\0"
    "_received_pushButtonEdgeDI2Changed\0"
    "_received_pushButtonEdgeDI3Changed\0"
    "_received_pushButtonEdgeDI4Changed\0"
    "_received_pushButtonEdgeAI1Changed\0"
    "_received_pushButtonEdgeAI2Changed\0"
    "_received_doubleSpinBoxDI1_valueChanged\0"
    "_received_doubleSpinBoxDI2_valueChanged\0"
    "_received_doubleSpinBoxDI3_valueChanged\0"
    "_received_doubleSpinBoxDI4_valueChanged\0"
    "_received_doubleSpinBoxAI1_valueChanged\0"
    "_received_doubleSpinBoxAI2_valueChanged\0"
    "_received_ComboBoxTopLeft_currentIndexChanged\0"
    "_received_ComboBoxTopRight_currentIndexChanged\0"
    "_received_ComboBoxBottomLeft_currentIndexChanged\0"
    "_received_ComboBoxBottomRight_currentIndexChanged\0"
    "_received_ComboBoxTopMiddle_currentIndexChanged\0"
    "_received_ComboBoxMiddle_currentIndexChanged\0"
    "_received_ComboBoxBottomMiddle_currentIndexChanged"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SettingWindow[] = {

 // content:
       7,       // revision
       0,       // classname
       0,    0, // classinfo
      99,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
      39,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,  509,    2, 0x06 /* Public */,
       4,    1,  512,    2, 0x06 /* Public */,
       5,    1,  515,    2, 0x06 /* Public */,
       6,    1,  518,    2, 0x06 /* Public */,
       7,    1,  521,    2, 0x06 /* Public */,
       9,    1,  524,    2, 0x06 /* Public */,
      11,    1,  527,    2, 0x06 /* Public */,
      13,    1,  530,    2, 0x06 /* Public */,
      15,    2,  533,    2, 0x06 /* Public */,
      18,    2,  538,    2, 0x06 /* Public */,
      19,    2,  543,    2, 0x06 /* Public */,
      20,    2,  548,    2, 0x06 /* Public */,
      21,    0,  553,    2, 0x06 /* Public */,
      22,    0,  554,    2, 0x06 /* Public */,
      23,    0,  555,    2, 0x06 /* Public */,
      24,    0,  556,    2, 0x06 /* Public */,
      25,    1,  557,    2, 0x06 /* Public */,
      27,    1,  560,    2, 0x06 /* Public */,
      28,    1,  563,    2, 0x06 /* Public */,
      29,    1,  566,    2, 0x06 /* Public */,
      30,    1,  569,    2, 0x06 /* Public */,
      32,    1,  572,    2, 0x06 /* Public */,
      33,    1,  575,    2, 0x06 /* Public */,
      34,    1,  578,    2, 0x06 /* Public */,
      35,    1,  581,    2, 0x06 /* Public */,
      36,    1,  584,    2, 0x06 /* Public */,
      37,    1,  587,    2, 0x06 /* Public */,
      39,    1,  590,    2, 0x06 /* Public */,
      40,    1,  593,    2, 0x06 /* Public */,
      41,    1,  596,    2, 0x06 /* Public */,
      42,    1,  599,    2, 0x06 /* Public */,
      43,    1,  602,    2, 0x06 /* Public */,
      44,    1,  605,    2, 0x06 /* Public */,
      46,    1,  608,    2, 0x06 /* Public */,
      47,    1,  611,    2, 0x06 /* Public */,
      48,    1,  614,    2, 0x06 /* Public */,
      49,    1,  617,    2, 0x06 /* Public */,
      50,    1,  620,    2, 0x06 /* Public */,
      51,    1,  623,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      52,    1,  626,    2, 0x0a /* Public */,
      54,    1,  629,    2, 0x0a /* Public */,
      55,    1,  632,    2, 0x0a /* Public */,
      56,    1,  635,    2, 0x0a /* Public */,
      57,    0,  638,    2, 0x0a /* Public */,
      58,    0,  639,    2, 0x0a /* Public */,
      59,    0,  640,    2, 0x0a /* Public */,
      60,    0,  641,    2, 0x0a /* Public */,
      61,    1,  642,    2, 0x0a /* Public */,
      62,    1,  645,    2, 0x0a /* Public */,
      63,    1,  648,    2, 0x0a /* Public */,
      64,    1,  651,    2, 0x0a /* Public */,
      65,    1,  654,    2, 0x0a /* Public */,
      66,    1,  657,    2, 0x0a /* Public */,
      67,    1,  660,    2, 0x0a /* Public */,
      68,    1,  663,    2, 0x0a /* Public */,
      69,    1,  666,    2, 0x0a /* Public */,
      70,    1,  669,    2, 0x0a /* Public */,
      71,    1,  672,    2, 0x0a /* Public */,
      72,    1,  675,    2, 0x0a /* Public */,
      73,    1,  678,    2, 0x0a /* Public */,
      74,    1,  681,    2, 0x0a /* Public */,
      75,    1,  684,    2, 0x0a /* Public */,
      76,    1,  687,    2, 0x0a /* Public */,
      77,    1,  690,    2, 0x0a /* Public */,
      78,    1,  693,    2, 0x0a /* Public */,
      79,    1,  696,    2, 0x0a /* Public */,
      80,    1,  699,    2, 0x08 /* Private */,
      81,    1,  702,    2, 0x08 /* Private */,
      82,    2,  705,    2, 0x08 /* Private */,
      83,    2,  710,    2, 0x08 /* Private */,
      84,    2,  715,    2, 0x08 /* Private */,
      85,    2,  720,    2, 0x08 /* Private */,
      86,    0,  725,    2, 0x08 /* Private */,
      87,    0,  726,    2, 0x08 /* Private */,
      88,    0,  727,    2, 0x08 /* Private */,
      89,    0,  728,    2, 0x08 /* Private */,
      90,    1,  729,    2, 0x08 /* Private */,
      91,    1,  732,    2, 0x08 /* Private */,
      92,    1,  735,    2, 0x08 /* Private */,
      93,    1,  738,    2, 0x08 /* Private */,
      94,    1,  741,    2, 0x08 /* Private */,
      95,    1,  744,    2, 0x08 /* Private */,
      96,    1,  747,    2, 0x08 /* Private */,
      97,    1,  750,    2, 0x08 /* Private */,
      98,    1,  753,    2, 0x08 /* Private */,
      99,    1,  756,    2, 0x08 /* Private */,
     100,    1,  759,    2, 0x08 /* Private */,
     101,    1,  762,    2, 0x08 /* Private */,
     102,    1,  765,    2, 0x08 /* Private */,
     103,    1,  768,    2, 0x08 /* Private */,
     104,    1,  771,    2, 0x08 /* Private */,
     105,    1,  774,    2, 0x08 /* Private */,
     106,    1,  777,    2, 0x08 /* Private */,
     107,    1,  780,    2, 0x08 /* Private */,
     108,    1,  783,    2, 0x08 /* Private */,
     109,    1,  786,    2, 0x08 /* Private */,
     110,    1,  789,    2, 0x08 /* Private */,
     111,    1,  792,    2, 0x08 /* Private */,
     112,    1,  795,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, QMetaType::UChar,    3,
    QMetaType::Void, QMetaType::UChar,    3,
    QMetaType::Void, QMetaType::UChar,    3,
    QMetaType::Void, QMetaType::UChar,    3,
    QMetaType::Void, QMetaType::ULongLong,    8,
    QMetaType::Void, QMetaType::Int,   10,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::UChar,   14,
    QMetaType::Void, QMetaType::UChar, QMetaType::Bool,   16,   17,
    QMetaType::Void, QMetaType::UChar, QMetaType::Bool,   16,   17,
    QMetaType::Void, QMetaType::UChar, QMetaType::Bool,   16,   17,
    QMetaType::Void, QMetaType::UChar, QMetaType::Bool,   16,   17,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   26,
    QMetaType::Void, QMetaType::QString,   26,
    QMetaType::Void, QMetaType::QString,   26,
    QMetaType::Void, QMetaType::QString,   26,
    QMetaType::Void, QMetaType::UChar,   31,
    QMetaType::Void, QMetaType::UChar,   31,
    QMetaType::Void, QMetaType::UChar,   31,
    QMetaType::Void, QMetaType::UChar,   31,
    QMetaType::Void, QMetaType::UChar,   31,
    QMetaType::Void, QMetaType::UChar,   31,
    QMetaType::Void, QMetaType::Double,   38,
    QMetaType::Void, QMetaType::Double,   38,
    QMetaType::Void, QMetaType::Double,   38,
    QMetaType::Void, QMetaType::Double,   38,
    QMetaType::Void, QMetaType::Double,   38,
    QMetaType::Void, QMetaType::Double,   38,
    QMetaType::Void, QMetaType::UChar,   45,
    QMetaType::Void, QMetaType::UChar,   45,
    QMetaType::Void, QMetaType::UChar,   45,
    QMetaType::Void, QMetaType::UChar,   45,
    QMetaType::Void, QMetaType::UChar,   45,
    QMetaType::Void, QMetaType::UChar,   45,
    QMetaType::Void, QMetaType::UChar,   45,

 // slots: parameters
    QMetaType::Void, QMetaType::ULongLong,   53,
    QMetaType::Void, QMetaType::Int,   10,
    QMetaType::Void, QMetaType::Int,   12,
    QMetaType::Void, QMetaType::UChar,   14,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::UChar,   31,
    QMetaType::Void, QMetaType::UChar,   31,
    QMetaType::Void, QMetaType::UChar,   31,
    QMetaType::Void, QMetaType::UChar,   31,
    QMetaType::Void, QMetaType::UChar,   31,
    QMetaType::Void, QMetaType::UChar,   31,
    QMetaType::Void, QMetaType::Double,   38,
    QMetaType::Void, QMetaType::Double,   38,
    QMetaType::Void, QMetaType::Double,   38,
    QMetaType::Void, QMetaType::Double,   38,
    QMetaType::Void, QMetaType::Double,   38,
    QMetaType::Void, QMetaType::Double,   38,
    QMetaType::Void, QMetaType::UChar,   45,
    QMetaType::Void, QMetaType::UChar,   45,
    QMetaType::Void, QMetaType::UChar,   45,
    QMetaType::Void, QMetaType::UChar,   45,
    QMetaType::Void, QMetaType::UChar,   45,
    QMetaType::Void, QMetaType::UChar,   45,
    QMetaType::Void, QMetaType::UChar,   45,
    QMetaType::Void, QMetaType::UChar,    3,
    QMetaType::Void, QMetaType::UChar,    3,
    QMetaType::Void, QMetaType::UChar, QMetaType::Bool,   16,   17,
    QMetaType::Void, QMetaType::UChar, QMetaType::Bool,   16,   17,
    QMetaType::Void, QMetaType::UChar, QMetaType::Bool,   16,   17,
    QMetaType::Void, QMetaType::UChar, QMetaType::Bool,   16,   17,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   26,
    QMetaType::Void, QMetaType::QString,   26,
    QMetaType::Void, QMetaType::QString,   26,
    QMetaType::Void, QMetaType::QString,   26,
    QMetaType::Void, QMetaType::UChar,   31,
    QMetaType::Void, QMetaType::UChar,   31,
    QMetaType::Void, QMetaType::UChar,   31,
    QMetaType::Void, QMetaType::UChar,   31,
    QMetaType::Void, QMetaType::UChar,   31,
    QMetaType::Void, QMetaType::UChar,   31,
    QMetaType::Void, QMetaType::Double,   38,
    QMetaType::Void, QMetaType::Double,   38,
    QMetaType::Void, QMetaType::Double,   38,
    QMetaType::Void, QMetaType::Double,   38,
    QMetaType::Void, QMetaType::Double,   38,
    QMetaType::Void, QMetaType::Double,   38,
    QMetaType::Void, QMetaType::UChar,   45,
    QMetaType::Void, QMetaType::UChar,   45,
    QMetaType::Void, QMetaType::UChar,   45,
    QMetaType::Void, QMetaType::UChar,   45,
    QMetaType::Void, QMetaType::UChar,   45,
    QMetaType::Void, QMetaType::UChar,   45,
    QMetaType::Void, QMetaType::UChar,   45,

       0        // eod
};

void SettingWindow::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        SettingWindow *_t = static_cast<SettingWindow *>(_o);
        switch (_id) {
        case 0: _t->_addTraceInTriggerMenu((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 1: _t->_removeTraceInTriggerMenu((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 2: _t->_addTraceInDisplayMenu((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 3: _t->_removeTraceInDisplayMenu((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 4: _t->_nbFrameSavedChange((*reinterpret_cast< quint64(*)>(_a[1]))); break;
        case 5: _t->_sizeFrameChange((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 6: _t->_FTDIBaudrateChange((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 7: _t->_percentPreTriggerWasChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 8: _t->_errorNoSelectedTrace((*reinterpret_cast< quint8(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 9: _t->_errorNoSelectedTriggerTrace((*reinterpret_cast< quint8(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 10: _t->_errorFrequencyToLow((*reinterpret_cast< quint8(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 11: _t->_errorWrongEquation((*reinterpret_cast< quint8(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 12: _t->_pushButtonRangeAI1WasChangedFromSettingMenu(); break;
        case 13: _t->_pushButtonRangeAI2WasChangedFromSettingMenu(); break;
        case 14: _t->_pushButtonRangeAI3WasChangedFromSettingMenu(); break;
        case 15: _t->_pushButtonRangeAI4WasChangedFromSettingMenu(); break;
        case 16: _t->_pushButtonRangeTXTAI1WasChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 17: _t->_pushButtonRangeTXTAI2WasChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 18: _t->_pushButtonRangeTXTAI3WasChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 19: _t->_pushButtonRangeTXTAI4WasChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 20: _t->_pushButtonEdgeDI1WasChangedFromSettingMenu((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 21: _t->_pushButtonEdgeDI2WasChangedFromSettingMenu((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 22: _t->_pushButtonEdgeDI3WasChangedFromSettingMenu((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 23: _t->_pushButtonEdgeDI4WasChangedFromSettingMenu((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 24: _t->_pushButtonEdgeAI1WasChangedFromSettingMenu((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 25: _t->_pushButtonEdgeAI2WasChangedFromSettingMenu((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 26: _t->_doubleSpinBoxDI1_valueWasChangedFromSettingMenu((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 27: _t->_doubleSpinBoxDI2_valueWasChangedFromSettingMenu((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 28: _t->_doubleSpinBoxDI3_valueWasChangedFromSettingMenu((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 29: _t->_doubleSpinBoxDI4_valueWasChangedFromSettingMenu((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 30: _t->_doubleSpinBoxAI1_valueWasChangedFromSettingMenu((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 31: _t->_doubleSpinBoxAI2_valueWasChangedFromSettingMenu((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 32: _t->_comboBoxTopLeft_currentIndexWasChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 33: _t->_comboBoxTopRight_currentIndexWasChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 34: _t->_comboBoxBottomLeft_currentIndexWasChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 35: _t->_comboBoxBottomRight_currentIndexWasChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 36: _t->_comboBoxTopMiddle_currentIndexWasChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 37: _t->_comboBoxMiddle_currentIndexWasChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 38: _t->_comboBoxBottomMiddle_currentIndexWasChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 39: _t->_received_NbFrameSavedChanged((*reinterpret_cast< quint64(*)>(_a[1]))); break;
        case 40: _t->_received_SizeFrameChange((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 41: _t->_received_FTDIBaudrateChange((*reinterpret_cast< int(*)>(_a[1]))); break;
        case 42: _t->_received_percentPreTriggerChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 43: _t->pushButtonRangeAI1_changeRange(); break;
        case 44: _t->pushButtonRangeAI2_changeRange(); break;
        case 45: _t->pushButtonRangeAI3_changeRange(); break;
        case 46: _t->pushButtonRangeAI4_changeRange(); break;
        case 47: _t->pushButtonEdgeDI1_changeEdge((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 48: _t->pushButtonEdgeDI2_changeEdge((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 49: _t->pushButtonEdgeDI3_changeEdge((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 50: _t->pushButtonEdgeDI4_changeEdge((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 51: _t->pushButtonEdgeAI1_changeEdge((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 52: _t->pushButtonEdgeAI2_changeEdge((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 53: _t->doubleSpinBoxDI1_changeValue((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 54: _t->doubleSpinBoxDI2_changeValue((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 55: _t->doubleSpinBoxDI3_changeValue((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 56: _t->doubleSpinBoxDI4_changeValue((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 57: _t->doubleSpinBoxAI1_changeValue((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 58: _t->doubleSpinBoxAI2_changeValue((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 59: _t->comboBoxTopLeft_changeCurrentIndex((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 60: _t->comboBoxTopRight_changeCurrentIndex((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 61: _t->comboBoxBottomLeft_changeCurrentIndex((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 62: _t->comboBoxBottomRight_changeCurrentIndex((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 63: _t->comboBoxTopMiddle_changeCurrentIndex((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 64: _t->comboBoxMiddle_changeCurrentIndex((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 65: _t->comboBoxBottomMiddle_changeCurrentIndex((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 66: _t->_received_AddTraceFromChannelSelection((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 67: _t->_received_RemoveTraceFromChannelSelection((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 68: _t->_received_errorNoSelectedTrace((*reinterpret_cast< quint8(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 69: _t->_received_errorNoSectedTriggerTrace((*reinterpret_cast< quint8(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 70: _t->_received_errorFrequencyToLow((*reinterpret_cast< quint8(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 71: _t->_received_errorWrongEquation((*reinterpret_cast< quint8(*)>(_a[1])),(*reinterpret_cast< bool(*)>(_a[2]))); break;
        case 72: _t->_received_pushButtonRangeAI1Changed(); break;
        case 73: _t->_received_pushButtonRangeAI2Changed(); break;
        case 74: _t->_received_pushButtonRangeAI3Changed(); break;
        case 75: _t->_received_pushButtonRangeAI4Changed(); break;
        case 76: _t->_received_pushButtonRangeAI1TXTWasChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 77: _t->_received_pushButtonRangeAI2TXTWasChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 78: _t->_received_pushButtonRangeAI3TXTWasChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 79: _t->_received_pushButtonRangeAI4TXTWasChanged((*reinterpret_cast< QString(*)>(_a[1]))); break;
        case 80: _t->_received_pushButtonEdgeDI1Changed((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 81: _t->_received_pushButtonEdgeDI2Changed((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 82: _t->_received_pushButtonEdgeDI3Changed((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 83: _t->_received_pushButtonEdgeDI4Changed((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 84: _t->_received_pushButtonEdgeAI1Changed((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 85: _t->_received_pushButtonEdgeAI2Changed((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 86: _t->_received_doubleSpinBoxDI1_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 87: _t->_received_doubleSpinBoxDI2_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 88: _t->_received_doubleSpinBoxDI3_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 89: _t->_received_doubleSpinBoxDI4_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 90: _t->_received_doubleSpinBoxAI1_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 91: _t->_received_doubleSpinBoxAI2_valueChanged((*reinterpret_cast< double(*)>(_a[1]))); break;
        case 92: _t->_received_ComboBoxTopLeft_currentIndexChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 93: _t->_received_ComboBoxTopRight_currentIndexChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 94: _t->_received_ComboBoxBottomLeft_currentIndexChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 95: _t->_received_ComboBoxBottomRight_currentIndexChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 96: _t->_received_ComboBoxTopMiddle_currentIndexChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 97: _t->_received_ComboBoxMiddle_currentIndexChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        case 98: _t->_received_ComboBoxBottomMiddle_currentIndexChanged((*reinterpret_cast< quint8(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        void **func = reinterpret_cast<void **>(_a[1]);
        {
            typedef void (SettingWindow::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_addTraceInTriggerMenu)) {
                *result = 0;
            }
        }
        {
            typedef void (SettingWindow::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_removeTraceInTriggerMenu)) {
                *result = 1;
            }
        }
        {
            typedef void (SettingWindow::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_addTraceInDisplayMenu)) {
                *result = 2;
            }
        }
        {
            typedef void (SettingWindow::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_removeTraceInDisplayMenu)) {
                *result = 3;
            }
        }
        {
            typedef void (SettingWindow::*_t)(quint64 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_nbFrameSavedChange)) {
                *result = 4;
            }
        }
        {
            typedef void (SettingWindow::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_sizeFrameChange)) {
                *result = 5;
            }
        }
        {
            typedef void (SettingWindow::*_t)(int );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_FTDIBaudrateChange)) {
                *result = 6;
            }
        }
        {
            typedef void (SettingWindow::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_percentPreTriggerWasChanged)) {
                *result = 7;
            }
        }
        {
            typedef void (SettingWindow::*_t)(quint8 , bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_errorNoSelectedTrace)) {
                *result = 8;
            }
        }
        {
            typedef void (SettingWindow::*_t)(quint8 , bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_errorNoSelectedTriggerTrace)) {
                *result = 9;
            }
        }
        {
            typedef void (SettingWindow::*_t)(quint8 , bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_errorFrequencyToLow)) {
                *result = 10;
            }
        }
        {
            typedef void (SettingWindow::*_t)(quint8 , bool );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_errorWrongEquation)) {
                *result = 11;
            }
        }
        {
            typedef void (SettingWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_pushButtonRangeAI1WasChangedFromSettingMenu)) {
                *result = 12;
            }
        }
        {
            typedef void (SettingWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_pushButtonRangeAI2WasChangedFromSettingMenu)) {
                *result = 13;
            }
        }
        {
            typedef void (SettingWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_pushButtonRangeAI3WasChangedFromSettingMenu)) {
                *result = 14;
            }
        }
        {
            typedef void (SettingWindow::*_t)();
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_pushButtonRangeAI4WasChangedFromSettingMenu)) {
                *result = 15;
            }
        }
        {
            typedef void (SettingWindow::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_pushButtonRangeTXTAI1WasChanged)) {
                *result = 16;
            }
        }
        {
            typedef void (SettingWindow::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_pushButtonRangeTXTAI2WasChanged)) {
                *result = 17;
            }
        }
        {
            typedef void (SettingWindow::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_pushButtonRangeTXTAI3WasChanged)) {
                *result = 18;
            }
        }
        {
            typedef void (SettingWindow::*_t)(QString );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_pushButtonRangeTXTAI4WasChanged)) {
                *result = 19;
            }
        }
        {
            typedef void (SettingWindow::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_pushButtonEdgeDI1WasChangedFromSettingMenu)) {
                *result = 20;
            }
        }
        {
            typedef void (SettingWindow::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_pushButtonEdgeDI2WasChangedFromSettingMenu)) {
                *result = 21;
            }
        }
        {
            typedef void (SettingWindow::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_pushButtonEdgeDI3WasChangedFromSettingMenu)) {
                *result = 22;
            }
        }
        {
            typedef void (SettingWindow::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_pushButtonEdgeDI4WasChangedFromSettingMenu)) {
                *result = 23;
            }
        }
        {
            typedef void (SettingWindow::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_pushButtonEdgeAI1WasChangedFromSettingMenu)) {
                *result = 24;
            }
        }
        {
            typedef void (SettingWindow::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_pushButtonEdgeAI2WasChangedFromSettingMenu)) {
                *result = 25;
            }
        }
        {
            typedef void (SettingWindow::*_t)(double );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_doubleSpinBoxDI1_valueWasChangedFromSettingMenu)) {
                *result = 26;
            }
        }
        {
            typedef void (SettingWindow::*_t)(double );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_doubleSpinBoxDI2_valueWasChangedFromSettingMenu)) {
                *result = 27;
            }
        }
        {
            typedef void (SettingWindow::*_t)(double );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_doubleSpinBoxDI3_valueWasChangedFromSettingMenu)) {
                *result = 28;
            }
        }
        {
            typedef void (SettingWindow::*_t)(double );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_doubleSpinBoxDI4_valueWasChangedFromSettingMenu)) {
                *result = 29;
            }
        }
        {
            typedef void (SettingWindow::*_t)(double );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_doubleSpinBoxAI1_valueWasChangedFromSettingMenu)) {
                *result = 30;
            }
        }
        {
            typedef void (SettingWindow::*_t)(double );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_doubleSpinBoxAI2_valueWasChangedFromSettingMenu)) {
                *result = 31;
            }
        }
        {
            typedef void (SettingWindow::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_comboBoxTopLeft_currentIndexWasChanged)) {
                *result = 32;
            }
        }
        {
            typedef void (SettingWindow::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_comboBoxTopRight_currentIndexWasChanged)) {
                *result = 33;
            }
        }
        {
            typedef void (SettingWindow::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_comboBoxBottomLeft_currentIndexWasChanged)) {
                *result = 34;
            }
        }
        {
            typedef void (SettingWindow::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_comboBoxBottomRight_currentIndexWasChanged)) {
                *result = 35;
            }
        }
        {
            typedef void (SettingWindow::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_comboBoxTopMiddle_currentIndexWasChanged)) {
                *result = 36;
            }
        }
        {
            typedef void (SettingWindow::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_comboBoxMiddle_currentIndexWasChanged)) {
                *result = 37;
            }
        }
        {
            typedef void (SettingWindow::*_t)(quint8 );
            if (*reinterpret_cast<_t *>(func) == static_cast<_t>(&SettingWindow::_comboBoxBottomMiddle_currentIndexWasChanged)) {
                *result = 38;
            }
        }
    }
}

const QMetaObject SettingWindow::staticMetaObject = {
    { &QWidget::staticMetaObject, qt_meta_stringdata_SettingWindow.data,
      qt_meta_data_SettingWindow,  qt_static_metacall, 0, 0}
};


const QMetaObject *SettingWindow::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SettingWindow::qt_metacast(const char *_clname)
{
    if (!_clname) return 0;
    if (!strcmp(_clname, qt_meta_stringdata_SettingWindow.stringdata))
        return static_cast<void*>(const_cast< SettingWindow*>(this));
    return QWidget::qt_metacast(_clname);
}

int SettingWindow::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QWidget::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 99)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 99;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 99)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 99;
    }
    return _id;
}

// SIGNAL 0
void SettingWindow::_addTraceInTriggerMenu(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void SettingWindow::_removeTraceInTriggerMenu(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void SettingWindow::_addTraceInDisplayMenu(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void SettingWindow::_removeTraceInDisplayMenu(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}

// SIGNAL 4
void SettingWindow::_nbFrameSavedChange(quint64 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 4, _a);
}

// SIGNAL 5
void SettingWindow::_sizeFrameChange(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 5, _a);
}

// SIGNAL 6
void SettingWindow::_FTDIBaudrateChange(int _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 6, _a);
}

// SIGNAL 7
void SettingWindow::_percentPreTriggerWasChanged(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 7, _a);
}

// SIGNAL 8
void SettingWindow::_errorNoSelectedTrace(quint8 _t1, bool _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 8, _a);
}

// SIGNAL 9
void SettingWindow::_errorNoSelectedTriggerTrace(quint8 _t1, bool _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 9, _a);
}

// SIGNAL 10
void SettingWindow::_errorFrequencyToLow(quint8 _t1, bool _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 10, _a);
}

// SIGNAL 11
void SettingWindow::_errorWrongEquation(quint8 _t1, bool _t2)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)), const_cast<void*>(reinterpret_cast<const void*>(&_t2)) };
    QMetaObject::activate(this, &staticMetaObject, 11, _a);
}

// SIGNAL 12
void SettingWindow::_pushButtonRangeAI1WasChangedFromSettingMenu()
{
    QMetaObject::activate(this, &staticMetaObject, 12, 0);
}

// SIGNAL 13
void SettingWindow::_pushButtonRangeAI2WasChangedFromSettingMenu()
{
    QMetaObject::activate(this, &staticMetaObject, 13, 0);
}

// SIGNAL 14
void SettingWindow::_pushButtonRangeAI3WasChangedFromSettingMenu()
{
    QMetaObject::activate(this, &staticMetaObject, 14, 0);
}

// SIGNAL 15
void SettingWindow::_pushButtonRangeAI4WasChangedFromSettingMenu()
{
    QMetaObject::activate(this, &staticMetaObject, 15, 0);
}

// SIGNAL 16
void SettingWindow::_pushButtonRangeTXTAI1WasChanged(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 16, _a);
}

// SIGNAL 17
void SettingWindow::_pushButtonRangeTXTAI2WasChanged(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 17, _a);
}

// SIGNAL 18
void SettingWindow::_pushButtonRangeTXTAI3WasChanged(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 18, _a);
}

// SIGNAL 19
void SettingWindow::_pushButtonRangeTXTAI4WasChanged(QString _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 19, _a);
}

// SIGNAL 20
void SettingWindow::_pushButtonEdgeDI1WasChangedFromSettingMenu(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 20, _a);
}

// SIGNAL 21
void SettingWindow::_pushButtonEdgeDI2WasChangedFromSettingMenu(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 21, _a);
}

// SIGNAL 22
void SettingWindow::_pushButtonEdgeDI3WasChangedFromSettingMenu(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 22, _a);
}

// SIGNAL 23
void SettingWindow::_pushButtonEdgeDI4WasChangedFromSettingMenu(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 23, _a);
}

// SIGNAL 24
void SettingWindow::_pushButtonEdgeAI1WasChangedFromSettingMenu(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 24, _a);
}

// SIGNAL 25
void SettingWindow::_pushButtonEdgeAI2WasChangedFromSettingMenu(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 25, _a);
}

// SIGNAL 26
void SettingWindow::_doubleSpinBoxDI1_valueWasChangedFromSettingMenu(double _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 26, _a);
}

// SIGNAL 27
void SettingWindow::_doubleSpinBoxDI2_valueWasChangedFromSettingMenu(double _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 27, _a);
}

// SIGNAL 28
void SettingWindow::_doubleSpinBoxDI3_valueWasChangedFromSettingMenu(double _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 28, _a);
}

// SIGNAL 29
void SettingWindow::_doubleSpinBoxDI4_valueWasChangedFromSettingMenu(double _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 29, _a);
}

// SIGNAL 30
void SettingWindow::_doubleSpinBoxAI1_valueWasChangedFromSettingMenu(double _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 30, _a);
}

// SIGNAL 31
void SettingWindow::_doubleSpinBoxAI2_valueWasChangedFromSettingMenu(double _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 31, _a);
}

// SIGNAL 32
void SettingWindow::_comboBoxTopLeft_currentIndexWasChanged(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 32, _a);
}

// SIGNAL 33
void SettingWindow::_comboBoxTopRight_currentIndexWasChanged(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 33, _a);
}

// SIGNAL 34
void SettingWindow::_comboBoxBottomLeft_currentIndexWasChanged(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 34, _a);
}

// SIGNAL 35
void SettingWindow::_comboBoxBottomRight_currentIndexWasChanged(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 35, _a);
}

// SIGNAL 36
void SettingWindow::_comboBoxTopMiddle_currentIndexWasChanged(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 36, _a);
}

// SIGNAL 37
void SettingWindow::_comboBoxMiddle_currentIndexWasChanged(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 37, _a);
}

// SIGNAL 38
void SettingWindow::_comboBoxBottomMiddle_currentIndexWasChanged(quint8 _t1)
{
    void *_a[] = { 0, const_cast<void*>(reinterpret_cast<const void*>(&_t1)) };
    QMetaObject::activate(this, &staticMetaObject, 38, _a);
}
QT_END_MOC_NAMESPACE
