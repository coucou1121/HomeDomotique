#ifndef SETTINGTIMESCALEFACTOR_H
#define SETTINGTIMESCALEFACTOR_H

/**
  * \file settingTimeScaleFactor.h
  * \author Sébastien Blessemaille
  * \version 1.0
  * \date 17 septembre 2017
  * \brief Frame in setting menu for the time scale factor selection
  */

#include <QFrame>
#include <QDebug>
#include <QString>
#include <QDateTime>
#include "commonStyle.h"
#include "globalEnumatedAndExtern.h"

namespace Ui {
class SettingTimeScaleFactor;
}

class SettingTimeScaleFactor : public QFrame
{
    Q_OBJECT

public:
    /**
      * \fn  explicit SettingTimeScaleFactor(QWidget *parent = 0)
      * \brief constructor for SettingTimeScaleFactor
      * \param[in] parent is the parent of the new widget.
      * If it is 0 (the default), the new widget will be a window.
      * If not, it will be a child of parent, and be constrained by parent's geometry
      */
    explicit SettingTimeScaleFactor(QWidget *parent = 0);

    /**
      * \fn  ~SettingTimeScaleFactor()
      * \brief destructor for SettingTimeScaleFactor
      */
    ~SettingTimeScaleFactor();

private:
    Ui::SettingTimeScaleFactor *ui;

    // _frequancy
    double _frequency;

    //nombre of saved frame
    quint64 _nbFrameSaved;

    //size of frame
    int _frameSize;

    //FTDI baudrate
    double _FTDIbaudrate;

    //key value for periode possible
    QMap<int, double> _peridePossible;

    //key value for text periode possible
    QMap<int, QString> _peridePossibleTxt;

    /**
      * \fn  void setupStyle()
      * \brief use to set the style of this object.
      * \return void : nothing
      */
    void setupStyle();

    /**
      * \fn  void _initPeriode();
      * \brief use to set the possible period to set in the application.
      * \return void : nothing
      */
    void _initPeriode();

    /**
      * \fn  void _initPeriode();
      * \brief use to calculate the duration
      * \return void : nothing
      */
    void _initDuration();

    /**
      * \fn  void _initPeriode();
      * \brief use to set the frequency on the application in the widget "time scale factor"
      * \return void : nothing
      */
    void _initSampleRate(int index);

private slots:

    void on_comboBoxPeriod_currentTextChanged(const QString &arg1);
    void on_comboBoxPeriod_currentIndexChanged(int index);

    void _nbFrameSavedWasChanged(quint64 nbFrameChanged);
    void _sizeFrameWasChanged(int frameSize);
    void _FTDIBaudrateWasChanged(int FTDIBaudrate);

signals:
    void _errorFrequencyToLow(quint8 errorNumber, bool active);
};

#endif // SETTINGTIMESCALEFACTOR_H
