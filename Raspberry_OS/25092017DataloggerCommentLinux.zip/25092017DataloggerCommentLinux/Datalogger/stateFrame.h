#ifndef STATEFRAME_H
#define STATEFRAME_H

//*

/**
  * \file stateFrame.h
  * \author Sébastien Blessemaille
  * \version 1.0
  * \date 17 septembre 2017
  * \brief Management of the state message
  */

#include <QWidget>
#include <QDebug>
#include "globalEnumatedAndExtern.h"

namespace Ui {
class StateFrame;
}

class StateFrame : public QWidget
{
    Q_OBJECT

public:
    /**
      * \fn  explicit StateFrame(QWidget *parent = 0)
      * \brief constructor for StateFrame
      * \param[in] parent is the parent of the new widget.
      * If it is 0 (the default), the new widget will be a window.
      * If not, it will be a child of parent, and be constrained by parent's geometry
      */
    explicit StateFrame(QWidget *parent = 0);

    /**
      * \fn  ~StateFrame()
      * \brief destructor for StateFrame
      */
    ~StateFrame();

    /**
      * \fn void setDisplayState(GlobalEnumatedAndExtern::eMainStateDisplay stateToDisplay)
      * \brief display the actual status of the application
      * \param[in] stateToDisplay is the status of the application
      * \return void : nothing
      */
    void setDisplayState(GlobalEnumatedAndExtern::eMainStateDisplay stateToDisplay);

private:
    Ui::StateFrame *ui;

    GlobalEnumatedAndExtern::eMainStateDisplay _mainsStateActualy;

    //key value for main state of application
    QMap<int, QString> _mainStatePossible;

    //logo
    QPixmap *_pixStateStop;
    QPixmap *_pixStatePause;
    QPixmap *_pixStateRunTrig;
    QPixmap *_pixStateOnTrig;
    QPixmap *_pixStateRollOn;
};

#endif // STATEFRAME_H
