/********************************************************************************
** Form generated from reading UI file 'analogPlot_copy.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ANALOGPLOT_COPY_H
#define UI_ANALOGPLOT_COPY_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_AnalogPlot
{
public:
    QGridLayout *gridLayout_2;
    QGridLayout *gridLayout;
    QCustomPlot *widget;
    QLabel *TLname;

    void setupUi(QWidget *AnalogPlot)
    {
        if (AnalogPlot->objectName().isEmpty())
            AnalogPlot->setObjectName(QStringLiteral("AnalogPlot"));
        AnalogPlot->resize(854, 257);
        QSizePolicy sizePolicy(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy.setHorizontalStretch(1);
        sizePolicy.setVerticalStretch(1);
        sizePolicy.setHeightForWidth(AnalogPlot->sizePolicy().hasHeightForWidth());
        AnalogPlot->setSizePolicy(sizePolicy);
        AnalogPlot->setMinimumSize(QSize(200, 22));
        gridLayout_2 = new QGridLayout(AnalogPlot);
        gridLayout_2->setSpacing(0);
        gridLayout_2->setObjectName(QStringLiteral("gridLayout_2"));
        gridLayout_2->setContentsMargins(0, 0, 0, 0);
        gridLayout = new QGridLayout();
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        widget = new QCustomPlot(AnalogPlot);
        widget->setObjectName(QStringLiteral("widget"));

        gridLayout->addWidget(widget, 0, 1, 1, 1);

        TLname = new QLabel(AnalogPlot);
        TLname->setObjectName(QStringLiteral("TLname"));
        TLname->setMinimumSize(QSize(20, 0));
        TLname->setMaximumSize(QSize(50, 16777215));
        TLname->setFrameShape(QFrame::Box);

        gridLayout->addWidget(TLname, 0, 0, 1, 1);


        gridLayout_2->addLayout(gridLayout, 0, 0, 1, 1);


        retranslateUi(AnalogPlot);

        QMetaObject::connectSlotsByName(AnalogPlot);
    } // setupUi

    void retranslateUi(QWidget *AnalogPlot)
    {
        AnalogPlot->setWindowTitle(QApplication::translate("AnalogPlot", "Form", 0));
        TLname->setText(QApplication::translate("AnalogPlot", "Title", 0));
    } // retranslateUi

};

namespace Ui {
    class AnalogPlot: public Ui_AnalogPlot {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ANALOGPLOT_COPY_H
