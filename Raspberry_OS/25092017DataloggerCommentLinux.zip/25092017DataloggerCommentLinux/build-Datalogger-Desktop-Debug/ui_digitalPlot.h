/********************************************************************************
** Form generated from reading UI file 'digitalPlot.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_DIGITALPLOT_H
#define UI_DIGITALPLOT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>
#include "qcustomplot.h"

QT_BEGIN_NAMESPACE

class Ui_DigitalPlot
{
public:
    QGridLayout *gridLayout_DI;
    QGridLayout *gridLayout_DI_IN;
    QCustomPlot *widget_DI;
    QLabel *labelTitleDI;

    void setupUi(QWidget *DigitalPlot)
    {
        if (DigitalPlot->objectName().isEmpty())
            DigitalPlot->setObjectName(QStringLiteral("DigitalPlot"));
        DigitalPlot->resize(854, 28);
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(DigitalPlot->sizePolicy().hasHeightForWidth());
        DigitalPlot->setSizePolicy(sizePolicy);
        DigitalPlot->setMaximumSize(QSize(16777215, 100));
        gridLayout_DI = new QGridLayout(DigitalPlot);
        gridLayout_DI->setSpacing(0);
        gridLayout_DI->setObjectName(QStringLiteral("gridLayout_DI"));
        gridLayout_DI->setContentsMargins(0, 0, 0, 0);
        gridLayout_DI_IN = new QGridLayout();
        gridLayout_DI_IN->setSpacing(0);
        gridLayout_DI_IN->setObjectName(QStringLiteral("gridLayout_DI_IN"));
        widget_DI = new QCustomPlot(DigitalPlot);
        widget_DI->setObjectName(QStringLiteral("widget_DI"));
        widget_DI->setMinimumSize(QSize(0, 20));
        widget_DI->setMaximumSize(QSize(16777215, 40));

        gridLayout_DI_IN->addWidget(widget_DI, 0, 1, 1, 1);

        labelTitleDI = new QLabel(DigitalPlot);
        labelTitleDI->setObjectName(QStringLiteral("labelTitleDI"));
        labelTitleDI->setMinimumSize(QSize(60, 20));
        labelTitleDI->setMaximumSize(QSize(60, 16777215));
        QFont font;
        font.setPointSize(12);
        labelTitleDI->setFont(font);
        labelTitleDI->setAutoFillBackground(true);
        labelTitleDI->setFrameShape(QFrame::Box);

        gridLayout_DI_IN->addWidget(labelTitleDI, 0, 0, 1, 1);


        gridLayout_DI->addLayout(gridLayout_DI_IN, 0, 0, 1, 1);


        retranslateUi(DigitalPlot);

        QMetaObject::connectSlotsByName(DigitalPlot);
    } // setupUi

    void retranslateUi(QWidget *DigitalPlot)
    {
        DigitalPlot->setWindowTitle(QApplication::translate("DigitalPlot", "Form", 0));
        labelTitleDI->setText(QApplication::translate("DigitalPlot", "Title", 0));
    } // retranslateUi

};

namespace Ui {
    class DigitalPlot: public Ui_DigitalPlot {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_DIGITALPLOT_H
