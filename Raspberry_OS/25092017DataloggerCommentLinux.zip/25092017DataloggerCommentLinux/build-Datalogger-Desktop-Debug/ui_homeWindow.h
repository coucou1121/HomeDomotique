/********************************************************************************
** Form generated from reading UI file 'homeWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_HOMEWINDOW_H
#define UI_HOMEWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_HomeWindow
{
public:
    QGridLayout *gridLayout;
    QLabel *LabelTitle;
    QLabel *labelVersion;

    void setupUi(QWidget *HomeWindow)
    {
        if (HomeWindow->objectName().isEmpty())
            HomeWindow->setObjectName(QStringLiteral("HomeWindow"));
        HomeWindow->resize(655, 330);
        gridLayout = new QGridLayout(HomeWindow);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(-1, -1, 50, -1);
        LabelTitle = new QLabel(HomeWindow);
        LabelTitle->setObjectName(QStringLiteral("LabelTitle"));
        QSizePolicy sizePolicy(QSizePolicy::MinimumExpanding, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(LabelTitle->sizePolicy().hasHeightForWidth());
        LabelTitle->setSizePolicy(sizePolicy);
        LabelTitle->setMaximumSize(QSize(16777215, 16777215));
        QFont font;
        font.setPointSize(100);
        LabelTitle->setFont(font);
        LabelTitle->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        LabelTitle->setMargin(0);
        LabelTitle->setIndent(-1);

        gridLayout->addWidget(LabelTitle, 0, 0, 1, 1);

        labelVersion = new QLabel(HomeWindow);
        labelVersion->setObjectName(QStringLiteral("labelVersion"));
        sizePolicy.setHeightForWidth(labelVersion->sizePolicy().hasHeightForWidth());
        labelVersion->setSizePolicy(sizePolicy);
        QFont font1;
        font1.setPointSize(50);
        labelVersion->setFont(font1);
        labelVersion->setAlignment(Qt::AlignRight|Qt::AlignTop|Qt::AlignTrailing);

        gridLayout->addWidget(labelVersion, 1, 0, 1, 1);


        retranslateUi(HomeWindow);

        QMetaObject::connectSlotsByName(HomeWindow);
    } // setupUi

    void retranslateUi(QWidget *HomeWindow)
    {
        HomeWindow->setWindowTitle(QApplication::translate("HomeWindow", "Form", 0));
        LabelTitle->setText(QApplication::translate("HomeWindow", "Unknow", 0));
        labelVersion->setText(QApplication::translate("HomeWindow", "Unknow", 0));
    } // retranslateUi

};

namespace Ui {
    class HomeWindow: public Ui_HomeWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_HOMEWINDOW_H
