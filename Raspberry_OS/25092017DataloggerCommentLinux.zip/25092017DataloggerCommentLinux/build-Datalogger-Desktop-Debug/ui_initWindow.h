/********************************************************************************
** Form generated from reading UI file 'initWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_INITWINDOW_H
#define UI_INITWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_InitWindow
{
public:
    QGridLayout *gridLayout;
    QLabel *initLabel;

    void setupUi(QFrame *InitWindow)
    {
        if (InitWindow->objectName().isEmpty())
            InitWindow->setObjectName(QStringLiteral("InitWindow"));
        InitWindow->resize(910, 850);
        InitWindow->setFrameShape(QFrame::StyledPanel);
        InitWindow->setFrameShadow(QFrame::Raised);
        gridLayout = new QGridLayout(InitWindow);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        initLabel = new QLabel(InitWindow);
        initLabel->setObjectName(QStringLiteral("initLabel"));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(initLabel->sizePolicy().hasHeightForWidth());
        initLabel->setSizePolicy(sizePolicy);
        initLabel->setMinimumSize(QSize(600, 500));
        initLabel->setMaximumSize(QSize(600, 500));
        QFont font;
        font.setBold(true);
        font.setWeight(75);
        initLabel->setFont(font);
        initLabel->setAutoFillBackground(false);
        initLabel->setStyleSheet(QStringLiteral("background-color: rgb(255, 255, 255);"));
        initLabel->setFrameShape(QFrame::Panel);
        initLabel->setFrameShadow(QFrame::Sunken);
        initLabel->setLineWidth(2);
        initLabel->setAlignment(Qt::AlignLeading|Qt::AlignLeft|Qt::AlignTop);
        initLabel->setWordWrap(true);
        initLabel->setMargin(0);

        gridLayout->addWidget(initLabel, 0, 0, 1, 1);


        retranslateUi(InitWindow);

        QMetaObject::connectSlotsByName(InitWindow);
    } // setupUi

    void retranslateUi(QFrame *InitWindow)
    {
        InitWindow->setWindowTitle(QApplication::translate("InitWindow", "Frame", 0));
        initLabel->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class InitWindow: public Ui_InitWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_INITWINDOW_H
