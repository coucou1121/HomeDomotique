/********************************************************************************
** Form generated from reading UI file 'ledManager.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_LEDMANAGER_H
#define UI_LEDMANAGER_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_ledManager
{
public:
    QGridLayout *gridLayout;
    QPushButton *pushButtonGreenLed;
    QPushButton *pushButtonAmberLed;
    QPushButton *pushButtonRedLed;

    void setupUi(QWidget *ledManager)
    {
        if (ledManager->objectName().isEmpty())
            ledManager->setObjectName(QStringLiteral("ledManager"));
        ledManager->resize(320, 103);
        gridLayout = new QGridLayout(ledManager);
        gridLayout->setSpacing(5);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(5, 5, 5, 5);
        pushButtonGreenLed = new QPushButton(ledManager);
        pushButtonGreenLed->setObjectName(QStringLiteral("pushButtonGreenLed"));
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(pushButtonGreenLed->sizePolicy().hasHeightForWidth());
        pushButtonGreenLed->setSizePolicy(sizePolicy);
        pushButtonGreenLed->setMinimumSize(QSize(80, 80));
        pushButtonGreenLed->setMaximumSize(QSize(80, 80));
        pushButtonGreenLed->setIconSize(QSize(75, 75));

        gridLayout->addWidget(pushButtonGreenLed, 0, 0, 1, 1);

        pushButtonAmberLed = new QPushButton(ledManager);
        pushButtonAmberLed->setObjectName(QStringLiteral("pushButtonAmberLed"));
        sizePolicy.setHeightForWidth(pushButtonAmberLed->sizePolicy().hasHeightForWidth());
        pushButtonAmberLed->setSizePolicy(sizePolicy);
        pushButtonAmberLed->setMinimumSize(QSize(80, 80));
        pushButtonAmberLed->setMaximumSize(QSize(80, 80));
        pushButtonAmberLed->setIconSize(QSize(75, 75));

        gridLayout->addWidget(pushButtonAmberLed, 0, 1, 1, 1);

        pushButtonRedLed = new QPushButton(ledManager);
        pushButtonRedLed->setObjectName(QStringLiteral("pushButtonRedLed"));
        sizePolicy.setHeightForWidth(pushButtonRedLed->sizePolicy().hasHeightForWidth());
        pushButtonRedLed->setSizePolicy(sizePolicy);
        pushButtonRedLed->setMinimumSize(QSize(80, 80));
        pushButtonRedLed->setMaximumSize(QSize(80, 80));
        pushButtonRedLed->setIconSize(QSize(75, 75));

        gridLayout->addWidget(pushButtonRedLed, 0, 2, 1, 1);


        retranslateUi(ledManager);

        QMetaObject::connectSlotsByName(ledManager);
    } // setupUi

    void retranslateUi(QWidget *ledManager)
    {
        ledManager->setWindowTitle(QApplication::translate("ledManager", "Form", 0));
        pushButtonGreenLed->setText(QString());
        pushButtonAmberLed->setText(QString());
        pushButtonRedLed->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class ledManager: public Ui_ledManager {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_LEDMANAGER_H
