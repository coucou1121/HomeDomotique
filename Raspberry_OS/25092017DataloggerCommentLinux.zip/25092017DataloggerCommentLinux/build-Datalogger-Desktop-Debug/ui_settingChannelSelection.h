/********************************************************************************
** Form generated from reading UI file 'settingChannelSelection.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SETTINGCHANNELSELECTION_H
#define UI_SETTINGCHANNELSELECTION_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_SettingChannelSelection
{
public:
    QGridLayout *gridLayout;
    QPushButton *btDI13;
    QPushButton *btDI11;
    QPushButton *btDI10;
    QPushButton *btDI4;
    QPushButton *btDI2;
    QPushButton *btAI1;
    QPushButton *btDI6;
    QPushButton *btDI16;
    QPushButton *btDI15;
    QPushButton *btDI5;
    QPushButton *btDI3;
    QPushButton *btDI1;
    QPushButton *btDI12;
    QPushButton *btDI7;
    QPushButton *btDI9;
    QPushButton *btDI14;
    QPushButton *btDI8;
    QLabel *labelTitleChanelSelection;
    QPushButton *btAI3;
    QPushButton *btAI2;
    QPushButton *btAI4;

    void setupUi(QFrame *SettingChannelSelection)
    {
        if (SettingChannelSelection->objectName().isEmpty())
            SettingChannelSelection->setObjectName(QStringLiteral("SettingChannelSelection"));
        SettingChannelSelection->resize(700, 170);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(SettingChannelSelection->sizePolicy().hasHeightForWidth());
        SettingChannelSelection->setSizePolicy(sizePolicy);
        SettingChannelSelection->setMinimumSize(QSize(700, 170));
        SettingChannelSelection->setMaximumSize(QSize(700, 170));
        QFont font;
        font.setKerning(false);
        SettingChannelSelection->setFont(font);
        SettingChannelSelection->setFrameShape(QFrame::Box);
        gridLayout = new QGridLayout(SettingChannelSelection);
        gridLayout->setSpacing(0);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(5, 5, 5, 5);
        btDI13 = new QPushButton(SettingChannelSelection);
        btDI13->setObjectName(QStringLiteral("btDI13"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(btDI13->sizePolicy().hasHeightForWidth());
        btDI13->setSizePolicy(sizePolicy1);
        btDI13->setMinimumSize(QSize(40, 40));
        QFont font1;
        font1.setPointSize(12);
        btDI13->setFont(font1);

        gridLayout->addWidget(btDI13, 2, 4, 1, 1);

        btDI11 = new QPushButton(SettingChannelSelection);
        btDI11->setObjectName(QStringLiteral("btDI11"));
        sizePolicy1.setHeightForWidth(btDI11->sizePolicy().hasHeightForWidth());
        btDI11->setSizePolicy(sizePolicy1);
        btDI11->setMinimumSize(QSize(40, 40));
        btDI11->setFont(font1);

        gridLayout->addWidget(btDI11, 2, 2, 1, 1);

        btDI10 = new QPushButton(SettingChannelSelection);
        btDI10->setObjectName(QStringLiteral("btDI10"));
        sizePolicy1.setHeightForWidth(btDI10->sizePolicy().hasHeightForWidth());
        btDI10->setSizePolicy(sizePolicy1);
        btDI10->setMinimumSize(QSize(40, 40));
        btDI10->setFont(font1);

        gridLayout->addWidget(btDI10, 2, 1, 1, 1);

        btDI4 = new QPushButton(SettingChannelSelection);
        btDI4->setObjectName(QStringLiteral("btDI4"));
        sizePolicy1.setHeightForWidth(btDI4->sizePolicy().hasHeightForWidth());
        btDI4->setSizePolicy(sizePolicy1);
        btDI4->setMinimumSize(QSize(40, 40));
        btDI4->setFont(font1);

        gridLayout->addWidget(btDI4, 1, 3, 1, 1);

        btDI2 = new QPushButton(SettingChannelSelection);
        btDI2->setObjectName(QStringLiteral("btDI2"));
        sizePolicy1.setHeightForWidth(btDI2->sizePolicy().hasHeightForWidth());
        btDI2->setSizePolicy(sizePolicy1);
        btDI2->setMinimumSize(QSize(40, 40));
        btDI2->setFont(font1);

        gridLayout->addWidget(btDI2, 1, 1, 1, 1);

        btAI1 = new QPushButton(SettingChannelSelection);
        btAI1->setObjectName(QStringLiteral("btAI1"));
        sizePolicy1.setHeightForWidth(btAI1->sizePolicy().hasHeightForWidth());
        btAI1->setSizePolicy(sizePolicy1);
        btAI1->setMinimumSize(QSize(40, 40));
        btAI1->setFont(font1);

        gridLayout->addWidget(btAI1, 3, 0, 1, 1);

        btDI6 = new QPushButton(SettingChannelSelection);
        btDI6->setObjectName(QStringLiteral("btDI6"));
        sizePolicy1.setHeightForWidth(btDI6->sizePolicy().hasHeightForWidth());
        btDI6->setSizePolicy(sizePolicy1);
        btDI6->setMinimumSize(QSize(40, 40));
        btDI6->setFont(font1);

        gridLayout->addWidget(btDI6, 1, 5, 1, 1);

        btDI16 = new QPushButton(SettingChannelSelection);
        btDI16->setObjectName(QStringLiteral("btDI16"));
        sizePolicy1.setHeightForWidth(btDI16->sizePolicy().hasHeightForWidth());
        btDI16->setSizePolicy(sizePolicy1);
        btDI16->setMinimumSize(QSize(40, 40));
        btDI16->setFont(font1);
        btDI16->setDefault(false);

        gridLayout->addWidget(btDI16, 2, 7, 1, 1);

        btDI15 = new QPushButton(SettingChannelSelection);
        btDI15->setObjectName(QStringLiteral("btDI15"));
        sizePolicy1.setHeightForWidth(btDI15->sizePolicy().hasHeightForWidth());
        btDI15->setSizePolicy(sizePolicy1);
        btDI15->setMinimumSize(QSize(40, 40));
        btDI15->setFont(font1);

        gridLayout->addWidget(btDI15, 2, 6, 1, 1);

        btDI5 = new QPushButton(SettingChannelSelection);
        btDI5->setObjectName(QStringLiteral("btDI5"));
        sizePolicy1.setHeightForWidth(btDI5->sizePolicy().hasHeightForWidth());
        btDI5->setSizePolicy(sizePolicy1);
        btDI5->setMinimumSize(QSize(40, 40));
        btDI5->setFont(font1);

        gridLayout->addWidget(btDI5, 1, 4, 1, 1);

        btDI3 = new QPushButton(SettingChannelSelection);
        btDI3->setObjectName(QStringLiteral("btDI3"));
        sizePolicy1.setHeightForWidth(btDI3->sizePolicy().hasHeightForWidth());
        btDI3->setSizePolicy(sizePolicy1);
        btDI3->setMinimumSize(QSize(40, 40));
        btDI3->setFont(font1);

        gridLayout->addWidget(btDI3, 1, 2, 1, 1);

        btDI1 = new QPushButton(SettingChannelSelection);
        btDI1->setObjectName(QStringLiteral("btDI1"));
        sizePolicy1.setHeightForWidth(btDI1->sizePolicy().hasHeightForWidth());
        btDI1->setSizePolicy(sizePolicy1);
        btDI1->setMinimumSize(QSize(40, 40));
        btDI1->setFont(font1);

        gridLayout->addWidget(btDI1, 1, 0, 1, 1);

        btDI12 = new QPushButton(SettingChannelSelection);
        btDI12->setObjectName(QStringLiteral("btDI12"));
        sizePolicy1.setHeightForWidth(btDI12->sizePolicy().hasHeightForWidth());
        btDI12->setSizePolicy(sizePolicy1);
        btDI12->setMinimumSize(QSize(40, 40));
        btDI12->setFont(font1);

        gridLayout->addWidget(btDI12, 2, 3, 1, 1);

        btDI7 = new QPushButton(SettingChannelSelection);
        btDI7->setObjectName(QStringLiteral("btDI7"));
        sizePolicy1.setHeightForWidth(btDI7->sizePolicy().hasHeightForWidth());
        btDI7->setSizePolicy(sizePolicy1);
        btDI7->setMinimumSize(QSize(40, 40));
        btDI7->setFont(font1);

        gridLayout->addWidget(btDI7, 1, 6, 1, 1);

        btDI9 = new QPushButton(SettingChannelSelection);
        btDI9->setObjectName(QStringLiteral("btDI9"));
        sizePolicy1.setHeightForWidth(btDI9->sizePolicy().hasHeightForWidth());
        btDI9->setSizePolicy(sizePolicy1);
        btDI9->setMinimumSize(QSize(40, 40));
        btDI9->setFont(font1);

        gridLayout->addWidget(btDI9, 2, 0, 1, 1);

        btDI14 = new QPushButton(SettingChannelSelection);
        btDI14->setObjectName(QStringLiteral("btDI14"));
        sizePolicy1.setHeightForWidth(btDI14->sizePolicy().hasHeightForWidth());
        btDI14->setSizePolicy(sizePolicy1);
        btDI14->setMinimumSize(QSize(40, 40));
        btDI14->setFont(font1);

        gridLayout->addWidget(btDI14, 2, 5, 1, 1);

        btDI8 = new QPushButton(SettingChannelSelection);
        btDI8->setObjectName(QStringLiteral("btDI8"));
        QSizePolicy sizePolicy2(QSizePolicy::Expanding, QSizePolicy::Minimum);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(btDI8->sizePolicy().hasHeightForWidth());
        btDI8->setSizePolicy(sizePolicy2);
        btDI8->setMinimumSize(QSize(40, 40));
        btDI8->setFont(font1);

        gridLayout->addWidget(btDI8, 1, 7, 1, 1);

        labelTitleChanelSelection = new QLabel(SettingChannelSelection);
        labelTitleChanelSelection->setObjectName(QStringLiteral("labelTitleChanelSelection"));
        QSizePolicy sizePolicy3(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(labelTitleChanelSelection->sizePolicy().hasHeightForWidth());
        labelTitleChanelSelection->setSizePolicy(sizePolicy3);
        labelTitleChanelSelection->setMinimumSize(QSize(0, 30));
        labelTitleChanelSelection->setFont(font1);
        labelTitleChanelSelection->setAlignment(Qt::AlignCenter);
        labelTitleChanelSelection->setMargin(0);

        gridLayout->addWidget(labelTitleChanelSelection, 0, 0, 1, 8);

        btAI3 = new QPushButton(SettingChannelSelection);
        btAI3->setObjectName(QStringLiteral("btAI3"));
        sizePolicy1.setHeightForWidth(btAI3->sizePolicy().hasHeightForWidth());
        btAI3->setSizePolicy(sizePolicy1);
        btAI3->setMinimumSize(QSize(40, 40));
        btAI3->setFont(font1);

        gridLayout->addWidget(btAI3, 3, 2, 1, 1);

        btAI2 = new QPushButton(SettingChannelSelection);
        btAI2->setObjectName(QStringLiteral("btAI2"));
        sizePolicy1.setHeightForWidth(btAI2->sizePolicy().hasHeightForWidth());
        btAI2->setSizePolicy(sizePolicy1);
        btAI2->setMinimumSize(QSize(40, 40));
        btAI2->setFont(font1);

        gridLayout->addWidget(btAI2, 3, 1, 1, 1);

        btAI4 = new QPushButton(SettingChannelSelection);
        btAI4->setObjectName(QStringLiteral("btAI4"));
        sizePolicy1.setHeightForWidth(btAI4->sizePolicy().hasHeightForWidth());
        btAI4->setSizePolicy(sizePolicy1);
        btAI4->setMinimumSize(QSize(40, 40));
        btAI4->setFont(font1);

        gridLayout->addWidget(btAI4, 3, 3, 1, 1);


        retranslateUi(SettingChannelSelection);

        QMetaObject::connectSlotsByName(SettingChannelSelection);
    } // setupUi

    void retranslateUi(QFrame *SettingChannelSelection)
    {
        SettingChannelSelection->setWindowTitle(QApplication::translate("SettingChannelSelection", "Form", 0));
        btDI13->setText(QString());
        btDI11->setText(QString());
        btDI10->setText(QString());
        btDI4->setText(QString());
        btDI2->setText(QString());
        btAI1->setText(QString());
        btDI6->setText(QString());
        btDI16->setText(QString());
        btDI15->setText(QString());
        btDI5->setText(QString());
        btDI3->setText(QString());
        btDI1->setText(QString());
        btDI12->setText(QString());
        btDI7->setText(QString());
        btDI9->setText(QString());
        btDI14->setText(QString());
        btDI8->setText(QString());
        labelTitleChanelSelection->setText(QApplication::translate("SettingChannelSelection", "Chanels selection", 0));
        btAI3->setText(QString());
        btAI2->setText(QString());
        btAI4->setText(QString());
    } // retranslateUi

};

namespace Ui {
    class SettingChannelSelection: public Ui_SettingChannelSelection {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SETTINGCHANNELSELECTION_H
