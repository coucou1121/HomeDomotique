/********************************************************************************
** Form generated from reading UI file 'settingPreTriggerPercentage.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SETTINGPRETRIGGERPERCENTAGE_H
#define UI_SETTINGPRETRIGGERPERCENTAGE_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QProgressBar>
#include <QtWidgets/QSpinBox>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_SettingPreTriggerPercentage
{
public:
    QGridLayout *gridLayout;
    QWidget *widgetTimeAfterBeforTrig;
    QGridLayout *gridLayoutTimeAfterTrig;
    QLabel *labelTimeAfterTrigTitle;
    QLabel *labelTimeAfterTrigUnit;
    QSpinBox *spinBoxTimeAfterTrig;
    QWidget *widgetTimeBeforTrig;
    QGridLayout *gridLayoutTimeBeforTrig;
    QLabel *labelTimeBeforTrigUnit;
    QLabel *labelTimeBeforTrigTitle;
    QSpinBox *spinBoxTimeBeforeTrig;
    QLabel *labelTimeUnit;
    QLabel *labelFlow;
    QLabel *labelMaxTime;
    QProgressBar *progressBar;
    QLabel *labelTitlePreTriggerPercentage;

    void setupUi(QFrame *SettingPreTriggerPercentage)
    {
        if (SettingPreTriggerPercentage->objectName().isEmpty())
            SettingPreTriggerPercentage->setObjectName(QStringLiteral("SettingPreTriggerPercentage"));
        SettingPreTriggerPercentage->resize(700, 210);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(SettingPreTriggerPercentage->sizePolicy().hasHeightForWidth());
        SettingPreTriggerPercentage->setSizePolicy(sizePolicy);
        SettingPreTriggerPercentage->setMinimumSize(QSize(170, 210));
        SettingPreTriggerPercentage->setMaximumSize(QSize(700, 210));
        QFont font;
        font.setPointSize(12);
        SettingPreTriggerPercentage->setFont(font);
        SettingPreTriggerPercentage->setFrameShape(QFrame::Box);
        gridLayout = new QGridLayout(SettingPreTriggerPercentage);
        gridLayout->setSpacing(5);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(5, 5, 5, 5);
        widgetTimeAfterBeforTrig = new QWidget(SettingPreTriggerPercentage);
        widgetTimeAfterBeforTrig->setObjectName(QStringLiteral("widgetTimeAfterBeforTrig"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(widgetTimeAfterBeforTrig->sizePolicy().hasHeightForWidth());
        widgetTimeAfterBeforTrig->setSizePolicy(sizePolicy1);
        widgetTimeAfterBeforTrig->setMinimumSize(QSize(0, 0));
        gridLayoutTimeAfterTrig = new QGridLayout(widgetTimeAfterBeforTrig);
        gridLayoutTimeAfterTrig->setObjectName(QStringLiteral("gridLayoutTimeAfterTrig"));
        gridLayoutTimeAfterTrig->setHorizontalSpacing(0);
        gridLayoutTimeAfterTrig->setVerticalSpacing(2);
        gridLayoutTimeAfterTrig->setContentsMargins(0, 0, 0, 0);
        labelTimeAfterTrigTitle = new QLabel(widgetTimeAfterBeforTrig);
        labelTimeAfterTrigTitle->setObjectName(QStringLiteral("labelTimeAfterTrigTitle"));
        sizePolicy1.setHeightForWidth(labelTimeAfterTrigTitle->sizePolicy().hasHeightForWidth());
        labelTimeAfterTrigTitle->setSizePolicy(sizePolicy1);
        labelTimeAfterTrigTitle->setMinimumSize(QSize(0, 40));
        labelTimeAfterTrigTitle->setMaximumSize(QSize(16777215, 40));
        labelTimeAfterTrigTitle->setAlignment(Qt::AlignCenter);

        gridLayoutTimeAfterTrig->addWidget(labelTimeAfterTrigTitle, 0, 1, 1, 2);

        labelTimeAfterTrigUnit = new QLabel(widgetTimeAfterBeforTrig);
        labelTimeAfterTrigUnit->setObjectName(QStringLiteral("labelTimeAfterTrigUnit"));
        QSizePolicy sizePolicy2(QSizePolicy::Fixed, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(labelTimeAfterTrigUnit->sizePolicy().hasHeightForWidth());
        labelTimeAfterTrigUnit->setSizePolicy(sizePolicy2);
        labelTimeAfterTrigUnit->setMinimumSize(QSize(40, 0));
        labelTimeAfterTrigUnit->setAlignment(Qt::AlignCenter);

        gridLayoutTimeAfterTrig->addWidget(labelTimeAfterTrigUnit, 1, 2, 1, 1);

        spinBoxTimeAfterTrig = new QSpinBox(widgetTimeAfterBeforTrig);
        spinBoxTimeAfterTrig->setObjectName(QStringLiteral("spinBoxTimeAfterTrig"));
        sizePolicy1.setHeightForWidth(spinBoxTimeAfterTrig->sizePolicy().hasHeightForWidth());
        spinBoxTimeAfterTrig->setSizePolicy(sizePolicy1);
        spinBoxTimeAfterTrig->setMinimumSize(QSize(150, 40));
        spinBoxTimeAfterTrig->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        spinBoxTimeAfterTrig->setButtonSymbols(QAbstractSpinBox::UpDownArrows);
        spinBoxTimeAfterTrig->setMaximum(2000);
        spinBoxTimeAfterTrig->setSingleStep(10);
        spinBoxTimeAfterTrig->setValue(0);

        gridLayoutTimeAfterTrig->addWidget(spinBoxTimeAfterTrig, 1, 1, 1, 1);


        gridLayout->addWidget(widgetTimeAfterBeforTrig, 3, 4, 2, 2);

        widgetTimeBeforTrig = new QWidget(SettingPreTriggerPercentage);
        widgetTimeBeforTrig->setObjectName(QStringLiteral("widgetTimeBeforTrig"));
        sizePolicy1.setHeightForWidth(widgetTimeBeforTrig->sizePolicy().hasHeightForWidth());
        widgetTimeBeforTrig->setSizePolicy(sizePolicy1);
        widgetTimeBeforTrig->setMinimumSize(QSize(0, 0));
        gridLayoutTimeBeforTrig = new QGridLayout(widgetTimeBeforTrig);
        gridLayoutTimeBeforTrig->setObjectName(QStringLiteral("gridLayoutTimeBeforTrig"));
        gridLayoutTimeBeforTrig->setHorizontalSpacing(0);
        gridLayoutTimeBeforTrig->setVerticalSpacing(2);
        gridLayoutTimeBeforTrig->setContentsMargins(0, 0, 0, 0);
        labelTimeBeforTrigUnit = new QLabel(widgetTimeBeforTrig);
        labelTimeBeforTrigUnit->setObjectName(QStringLiteral("labelTimeBeforTrigUnit"));
        sizePolicy2.setHeightForWidth(labelTimeBeforTrigUnit->sizePolicy().hasHeightForWidth());
        labelTimeBeforTrigUnit->setSizePolicy(sizePolicy2);
        labelTimeBeforTrigUnit->setMinimumSize(QSize(40, 0));
        labelTimeBeforTrigUnit->setAlignment(Qt::AlignCenter);

        gridLayoutTimeBeforTrig->addWidget(labelTimeBeforTrigUnit, 1, 1, 1, 1);

        labelTimeBeforTrigTitle = new QLabel(widgetTimeBeforTrig);
        labelTimeBeforTrigTitle->setObjectName(QStringLiteral("labelTimeBeforTrigTitle"));
        QSizePolicy sizePolicy3(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(labelTimeBeforTrigTitle->sizePolicy().hasHeightForWidth());
        labelTimeBeforTrigTitle->setSizePolicy(sizePolicy3);
        labelTimeBeforTrigTitle->setMinimumSize(QSize(0, 40));
        labelTimeBeforTrigTitle->setMaximumSize(QSize(16777215, 40));
        labelTimeBeforTrigTitle->setAlignment(Qt::AlignCenter);

        gridLayoutTimeBeforTrig->addWidget(labelTimeBeforTrigTitle, 0, 0, 1, 3);

        spinBoxTimeBeforeTrig = new QSpinBox(widgetTimeBeforTrig);
        spinBoxTimeBeforeTrig->setObjectName(QStringLiteral("spinBoxTimeBeforeTrig"));
        sizePolicy1.setHeightForWidth(spinBoxTimeBeforeTrig->sizePolicy().hasHeightForWidth());
        spinBoxTimeBeforeTrig->setSizePolicy(sizePolicy1);
        spinBoxTimeBeforeTrig->setMinimumSize(QSize(150, 40));
        spinBoxTimeBeforeTrig->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        spinBoxTimeBeforeTrig->setButtonSymbols(QAbstractSpinBox::UpDownArrows);
        spinBoxTimeBeforeTrig->setMaximum(2000);
        spinBoxTimeBeforeTrig->setSingleStep(10);
        spinBoxTimeBeforeTrig->setValue(0);

        gridLayoutTimeBeforTrig->addWidget(spinBoxTimeBeforeTrig, 1, 0, 1, 1);


        gridLayout->addWidget(widgetTimeBeforTrig, 3, 1, 2, 1);

        labelTimeUnit = new QLabel(SettingPreTriggerPercentage);
        labelTimeUnit->setObjectName(QStringLiteral("labelTimeUnit"));
        labelTimeUnit->setAlignment(Qt::AlignHCenter|Qt::AlignTop);

        gridLayout->addWidget(labelTimeUnit, 4, 3, 1, 1);

        labelFlow = new QLabel(SettingPreTriggerPercentage);
        labelFlow->setObjectName(QStringLiteral("labelFlow"));
        sizePolicy3.setHeightForWidth(labelFlow->sizePolicy().hasHeightForWidth());
        labelFlow->setSizePolicy(sizePolicy3);
        labelFlow->setMinimumSize(QSize(50, 0));
        labelFlow->setPixmap(QPixmap(QString::fromUtf8(":/images/DoubleFlow.png")));
        labelFlow->setScaledContents(true);
        labelFlow->setAlignment(Qt::AlignCenter);
        labelFlow->setWordWrap(false);
        labelFlow->setIndent(-1);

        gridLayout->addWidget(labelFlow, 2, 1, 1, 5);

        labelMaxTime = new QLabel(SettingPreTriggerPercentage);
        labelMaxTime->setObjectName(QStringLiteral("labelMaxTime"));
        QSizePolicy sizePolicy4(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(0);
        sizePolicy4.setHeightForWidth(labelMaxTime->sizePolicy().hasHeightForWidth());
        labelMaxTime->setSizePolicy(sizePolicy4);
        labelMaxTime->setMinimumSize(QSize(200, 0));
        QFont font1;
        font1.setPointSize(20);
        font1.setBold(true);
        font1.setWeight(75);
        font1.setKerning(true);
        labelMaxTime->setFont(font1);
        labelMaxTime->setAlignment(Qt::AlignHCenter|Qt::AlignTop);

        gridLayout->addWidget(labelMaxTime, 3, 3, 1, 1);

        progressBar = new QProgressBar(SettingPreTriggerPercentage);
        progressBar->setObjectName(QStringLiteral("progressBar"));
        sizePolicy3.setHeightForWidth(progressBar->sizePolicy().hasHeightForWidth());
        progressBar->setSizePolicy(sizePolicy3);
        progressBar->setValue(0);
        progressBar->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(progressBar, 1, 1, 1, 5);

        labelTitlePreTriggerPercentage = new QLabel(SettingPreTriggerPercentage);
        labelTitlePreTriggerPercentage->setObjectName(QStringLiteral("labelTitlePreTriggerPercentage"));
        sizePolicy3.setHeightForWidth(labelTitlePreTriggerPercentage->sizePolicy().hasHeightForWidth());
        labelTitlePreTriggerPercentage->setSizePolicy(sizePolicy3);
        labelTitlePreTriggerPercentage->setMinimumSize(QSize(0, 30));
        labelTitlePreTriggerPercentage->setFont(font);
        labelTitlePreTriggerPercentage->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(labelTitlePreTriggerPercentage, 0, 1, 1, 5);


        retranslateUi(SettingPreTriggerPercentage);

        QMetaObject::connectSlotsByName(SettingPreTriggerPercentage);
    } // setupUi

    void retranslateUi(QFrame *SettingPreTriggerPercentage)
    {
        SettingPreTriggerPercentage->setWindowTitle(QApplication::translate("SettingPreTriggerPercentage", "Form", 0));
        labelTimeAfterTrigTitle->setText(QApplication::translate("SettingPreTriggerPercentage", "Time after trig", 0));
        labelTimeAfterTrigUnit->setText(QApplication::translate("SettingPreTriggerPercentage", "[ms]", 0));
        labelTimeBeforTrigUnit->setText(QApplication::translate("SettingPreTriggerPercentage", "[ms]", 0));
        labelTimeBeforTrigTitle->setText(QApplication::translate("SettingPreTriggerPercentage", "Time befor trig", 0));
        labelTimeUnit->setText(QApplication::translate("SettingPreTriggerPercentage", "[sec]", 0));
        labelFlow->setText(QString());
        labelMaxTime->setText(QApplication::translate("SettingPreTriggerPercentage", "xx", 0));
        labelTitlePreTriggerPercentage->setText(QApplication::translate("SettingPreTriggerPercentage", "Pre-trigger percentage", 0));
    } // retranslateUi

};

namespace Ui {
    class SettingPreTriggerPercentage: public Ui_SettingPreTriggerPercentage {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SETTINGPRETRIGGERPERCENTAGE_H
