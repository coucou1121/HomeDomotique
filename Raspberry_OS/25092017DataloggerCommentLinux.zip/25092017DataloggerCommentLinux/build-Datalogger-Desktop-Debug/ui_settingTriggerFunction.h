/********************************************************************************
** Form generated from reading UI file 'settingTriggerFunction.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SETTINGTRIGGERFUNCTION_H
#define UI_SETTINGTRIGGERFUNCTION_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QComboBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>

QT_BEGIN_NAMESPACE

class Ui_SettingTriggerFunction
{
public:
    QGridLayout *gridLayout;
    QComboBox *comboBoxBottomRight;
    QLabel *labelTitleTriggerFunction;
    QLabel *labelBottomLeft;
    QComboBox *comboBoxBottomLeft;
    QComboBox *comboBoxTopMiddle;
    QComboBox *comboBoxTopLeft;
    QComboBox *comboBoxBottomMiddle;
    QComboBox *comboBoxMiddle;
    QLabel *labelTopLeft;
    QLabel *labelBottomRight;
    QComboBox *comboBoxTopRight;
    QLabel *labelTopRight;

    void setupUi(QFrame *SettingTriggerFunction)
    {
        if (SettingTriggerFunction->objectName().isEmpty())
            SettingTriggerFunction->setObjectName(QStringLiteral("SettingTriggerFunction"));
        SettingTriggerFunction->resize(300, 160);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(SettingTriggerFunction->sizePolicy().hasHeightForWidth());
        SettingTriggerFunction->setSizePolicy(sizePolicy);
        SettingTriggerFunction->setMinimumSize(QSize(300, 160));
        SettingTriggerFunction->setMaximumSize(QSize(300, 160));
        QFont font;
        font.setPointSize(12);
        SettingTriggerFunction->setFont(font);
        SettingTriggerFunction->setFrameShape(QFrame::Box);
        gridLayout = new QGridLayout(SettingTriggerFunction);
        gridLayout->setSpacing(5);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(5, 5, 5, 5);
        comboBoxBottomRight = new QComboBox(SettingTriggerFunction);
        comboBoxBottomRight->setObjectName(QStringLiteral("comboBoxBottomRight"));
        QSizePolicy sizePolicy1(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(comboBoxBottomRight->sizePolicy().hasHeightForWidth());
        comboBoxBottomRight->setSizePolicy(sizePolicy1);
        comboBoxBottomRight->setMinimumSize(QSize(50, 0));
        comboBoxBottomRight->setFont(font);

        gridLayout->addWidget(comboBoxBottomRight, 3, 3, 1, 1);

        labelTitleTriggerFunction = new QLabel(SettingTriggerFunction);
        labelTitleTriggerFunction->setObjectName(QStringLiteral("labelTitleTriggerFunction"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(labelTitleTriggerFunction->sizePolicy().hasHeightForWidth());
        labelTitleTriggerFunction->setSizePolicy(sizePolicy2);
        labelTitleTriggerFunction->setMinimumSize(QSize(0, 30));
        labelTitleTriggerFunction->setFont(font);
        labelTitleTriggerFunction->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(labelTitleTriggerFunction, 0, 0, 1, 5);

        labelBottomLeft = new QLabel(SettingTriggerFunction);
        labelBottomLeft->setObjectName(QStringLiteral("labelBottomLeft"));
        sizePolicy.setHeightForWidth(labelBottomLeft->sizePolicy().hasHeightForWidth());
        labelBottomLeft->setSizePolicy(sizePolicy);
        labelBottomLeft->setMinimumSize(QSize(8, 20));
        labelBottomLeft->setMaximumSize(QSize(8, 16777215));
        QFont font1;
        font1.setPointSize(12);
        font1.setBold(true);
        font1.setWeight(75);
        labelBottomLeft->setFont(font1);
        labelBottomLeft->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(labelBottomLeft, 3, 0, 1, 1);

        comboBoxBottomLeft = new QComboBox(SettingTriggerFunction);
        comboBoxBottomLeft->setObjectName(QStringLiteral("comboBoxBottomLeft"));
        sizePolicy1.setHeightForWidth(comboBoxBottomLeft->sizePolicy().hasHeightForWidth());
        comboBoxBottomLeft->setSizePolicy(sizePolicy1);
        comboBoxBottomLeft->setMinimumSize(QSize(50, 0));
        comboBoxBottomLeft->setFont(font);

        gridLayout->addWidget(comboBoxBottomLeft, 3, 1, 1, 1);

        comboBoxTopMiddle = new QComboBox(SettingTriggerFunction);
        comboBoxTopMiddle->setObjectName(QStringLiteral("comboBoxTopMiddle"));
        QSizePolicy sizePolicy3(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(comboBoxTopMiddle->sizePolicy().hasHeightForWidth());
        comboBoxTopMiddle->setSizePolicy(sizePolicy3);
        comboBoxTopMiddle->setMinimumSize(QSize(50, 0));
        comboBoxTopMiddle->setMaximumSize(QSize(16777215, 16777215));
        comboBoxTopMiddle->setFont(font1);

        gridLayout->addWidget(comboBoxTopMiddle, 1, 2, 1, 1);

        comboBoxTopLeft = new QComboBox(SettingTriggerFunction);
        comboBoxTopLeft->setObjectName(QStringLiteral("comboBoxTopLeft"));
        sizePolicy1.setHeightForWidth(comboBoxTopLeft->sizePolicy().hasHeightForWidth());
        comboBoxTopLeft->setSizePolicy(sizePolicy1);
        comboBoxTopLeft->setMinimumSize(QSize(50, 0));
        QFont font2;
        font2.setFamily(QStringLiteral("MS Shell Dlg 2"));
        font2.setPointSize(12);
        comboBoxTopLeft->setFont(font2);
        comboBoxTopLeft->setInsertPolicy(QComboBox::InsertAlphabetically);

        gridLayout->addWidget(comboBoxTopLeft, 1, 1, 1, 1);

        comboBoxBottomMiddle = new QComboBox(SettingTriggerFunction);
        comboBoxBottomMiddle->setObjectName(QStringLiteral("comboBoxBottomMiddle"));
        sizePolicy3.setHeightForWidth(comboBoxBottomMiddle->sizePolicy().hasHeightForWidth());
        comboBoxBottomMiddle->setSizePolicy(sizePolicy3);
        comboBoxBottomMiddle->setMinimumSize(QSize(50, 0));
        comboBoxBottomMiddle->setMaximumSize(QSize(16777215, 16777215));
        comboBoxBottomMiddle->setFont(font1);

        gridLayout->addWidget(comboBoxBottomMiddle, 3, 2, 1, 1);

        comboBoxMiddle = new QComboBox(SettingTriggerFunction);
        comboBoxMiddle->setObjectName(QStringLiteral("comboBoxMiddle"));
        sizePolicy3.setHeightForWidth(comboBoxMiddle->sizePolicy().hasHeightForWidth());
        comboBoxMiddle->setSizePolicy(sizePolicy3);
        comboBoxMiddle->setMinimumSize(QSize(50, 0));
        comboBoxMiddle->setMaximumSize(QSize(16777215, 16777215));
        comboBoxMiddle->setFont(font1);

        gridLayout->addWidget(comboBoxMiddle, 2, 2, 1, 1);

        labelTopLeft = new QLabel(SettingTriggerFunction);
        labelTopLeft->setObjectName(QStringLiteral("labelTopLeft"));
        sizePolicy.setHeightForWidth(labelTopLeft->sizePolicy().hasHeightForWidth());
        labelTopLeft->setSizePolicy(sizePolicy);
        labelTopLeft->setMinimumSize(QSize(8, 20));
        labelTopLeft->setMaximumSize(QSize(8, 16777215));
        labelTopLeft->setFont(font1);
        labelTopLeft->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(labelTopLeft, 1, 0, 1, 1);

        labelBottomRight = new QLabel(SettingTriggerFunction);
        labelBottomRight->setObjectName(QStringLiteral("labelBottomRight"));
        sizePolicy.setHeightForWidth(labelBottomRight->sizePolicy().hasHeightForWidth());
        labelBottomRight->setSizePolicy(sizePolicy);
        labelBottomRight->setMinimumSize(QSize(8, 20));
        labelBottomRight->setMaximumSize(QSize(8, 16777215));
        labelBottomRight->setFont(font1);

        gridLayout->addWidget(labelBottomRight, 3, 4, 1, 1);

        comboBoxTopRight = new QComboBox(SettingTriggerFunction);
        comboBoxTopRight->setObjectName(QStringLiteral("comboBoxTopRight"));
        sizePolicy1.setHeightForWidth(comboBoxTopRight->sizePolicy().hasHeightForWidth());
        comboBoxTopRight->setSizePolicy(sizePolicy1);
        comboBoxTopRight->setMinimumSize(QSize(50, 0));
        comboBoxTopRight->setFont(font);

        gridLayout->addWidget(comboBoxTopRight, 1, 3, 1, 1);

        labelTopRight = new QLabel(SettingTriggerFunction);
        labelTopRight->setObjectName(QStringLiteral("labelTopRight"));
        sizePolicy.setHeightForWidth(labelTopRight->sizePolicy().hasHeightForWidth());
        labelTopRight->setSizePolicy(sizePolicy);
        labelTopRight->setMinimumSize(QSize(8, 20));
        labelTopRight->setMaximumSize(QSize(8, 16777215));
        labelTopRight->setFont(font1);

        gridLayout->addWidget(labelTopRight, 1, 4, 1, 1);


        retranslateUi(SettingTriggerFunction);

        QMetaObject::connectSlotsByName(SettingTriggerFunction);
    } // setupUi

    void retranslateUi(QFrame *SettingTriggerFunction)
    {
        SettingTriggerFunction->setWindowTitle(QApplication::translate("SettingTriggerFunction", "Form", 0));
        labelTitleTriggerFunction->setText(QApplication::translate("SettingTriggerFunction", "Trigger Function", 0));
        labelBottomLeft->setText(QApplication::translate("SettingTriggerFunction", "(", 0));
        labelTopLeft->setText(QApplication::translate("SettingTriggerFunction", "(", 0));
        labelBottomRight->setText(QApplication::translate("SettingTriggerFunction", ")", 0));
        labelTopRight->setText(QApplication::translate("SettingTriggerFunction", ")", 0));
    } // retranslateUi

};

namespace Ui {
    class SettingTriggerFunction: public Ui_SettingTriggerFunction {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SETTINGTRIGGERFUNCTION_H
