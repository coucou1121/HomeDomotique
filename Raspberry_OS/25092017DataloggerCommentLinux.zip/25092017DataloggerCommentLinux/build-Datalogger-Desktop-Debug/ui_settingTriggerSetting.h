/********************************************************************************
** Form generated from reading UI file 'settingTriggerSetting.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SETTINGTRIGGERSETTING_H
#define UI_SETTINGTRIGGERSETTING_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QDoubleSpinBox>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>

QT_BEGIN_NAMESPACE

class Ui_SettingTriggerSetting
{
public:
    QGridLayout *gridLayout;
    QLabel *labelAI4;
    QLabel *labelRange;
    QDoubleSpinBox *doubleSpinBoxDI3;
    QPushButton *pushButtonRangeAI4;
    QDoubleSpinBox *doubleSpinBoxDI1;
    QDoubleSpinBox *doubleSpinBoxDI4;
    QDoubleSpinBox *doubleSpinBoxAI1;
    QPushButton *pushButtonRangeDI3;
    QPushButton *pushButtonRangeDI4;
    QPushButton *pushButtonRangeDI1;
    QDoubleSpinBox *doubleSpinBoxDI2;
    QPushButton *pushButtonRangeDI2;
    QDoubleSpinBox *doubleSpinBoxAI2;
    QPushButton *pushButtonRangeAI3;
    QLabel *labelAI3;
    QLabel *labelTitleTriggerSetting;
    QPushButton *pushButtonRangeAI1;
    QLabel *labelAI2;
    QLabel *labelLevel;
    QLabel *labelDI3;
    QLabel *labelDI2;
    QLabel *labelDI4;
    QPushButton *pushButtonRangeAI2;
    QLabel *labelDI1;
    QLabel *labelAI1;
    QPushButton *pushButtonEdgeDI1;
    QPushButton *pushButtonEdgeDI2;
    QPushButton *pushButtonEdgeDI3;
    QPushButton *pushButtonEdgeDI4;
    QPushButton *pushButtonEdgeAI1;
    QPushButton *pushButtonEdgeAI2;
    QLabel *labelEdge;

    void setupUi(QFrame *SettingTriggerSetting)
    {
        if (SettingTriggerSetting->objectName().isEmpty())
            SettingTriggerSetting->setObjectName(QStringLiteral("SettingTriggerSetting"));
        SettingTriggerSetting->resize(300, 460);
        QSizePolicy sizePolicy(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(SettingTriggerSetting->sizePolicy().hasHeightForWidth());
        SettingTriggerSetting->setSizePolicy(sizePolicy);
        SettingTriggerSetting->setMinimumSize(QSize(300, 460));
        SettingTriggerSetting->setMaximumSize(QSize(300, 460));
        QFont font;
        font.setPointSize(12);
        font.setKerning(true);
        SettingTriggerSetting->setFont(font);
        SettingTriggerSetting->setFrameShape(QFrame::Box);
        gridLayout = new QGridLayout(SettingTriggerSetting);
        gridLayout->setSpacing(5);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(5, 5, 5, 5);
        labelAI4 = new QLabel(SettingTriggerSetting);
        labelAI4->setObjectName(QStringLiteral("labelAI4"));
        QSizePolicy sizePolicy1(QSizePolicy::Expanding, QSizePolicy::Expanding);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(labelAI4->sizePolicy().hasHeightForWidth());
        labelAI4->setSizePolicy(sizePolicy1);
        labelAI4->setMinimumSize(QSize(40, 40));
        labelAI4->setMaximumSize(QSize(40, 40));
        labelAI4->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(labelAI4, 10, 0, 1, 1);

        labelRange = new QLabel(SettingTriggerSetting);
        labelRange->setObjectName(QStringLiteral("labelRange"));
        QSizePolicy sizePolicy2(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(30);
        sizePolicy2.setHeightForWidth(labelRange->sizePolicy().hasHeightForWidth());
        labelRange->setSizePolicy(sizePolicy2);
        labelRange->setMinimumSize(QSize(40, 40));
        labelRange->setLineWidth(0);
        labelRange->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(labelRange, 1, 0, 1, 2);

        doubleSpinBoxDI3 = new QDoubleSpinBox(SettingTriggerSetting);
        doubleSpinBoxDI3->setObjectName(QStringLiteral("doubleSpinBoxDI3"));
        sizePolicy1.setHeightForWidth(doubleSpinBoxDI3->sizePolicy().hasHeightForWidth());
        doubleSpinBoxDI3->setSizePolicy(sizePolicy1);
        doubleSpinBoxDI3->setMinimumSize(QSize(120, 40));
        doubleSpinBoxDI3->setMaximumSize(QSize(120, 40));
        doubleSpinBoxDI3->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        doubleSpinBoxDI3->setDecimals(1);
        doubleSpinBoxDI3->setMaximum(24);
        doubleSpinBoxDI3->setSingleStep(0.1);
        doubleSpinBoxDI3->setValue(0);

        gridLayout->addWidget(doubleSpinBoxDI3, 4, 2, 1, 2);

        pushButtonRangeAI4 = new QPushButton(SettingTriggerSetting);
        pushButtonRangeAI4->setObjectName(QStringLiteral("pushButtonRangeAI4"));
        sizePolicy1.setHeightForWidth(pushButtonRangeAI4->sizePolicy().hasHeightForWidth());
        pushButtonRangeAI4->setSizePolicy(sizePolicy1);
        pushButtonRangeAI4->setMinimumSize(QSize(60, 40));
        pushButtonRangeAI4->setMaximumSize(QSize(60, 40));
        pushButtonRangeAI4->setAutoFillBackground(true);
        pushButtonRangeAI4->setIconSize(QSize(10, 10));

        gridLayout->addWidget(pushButtonRangeAI4, 10, 1, 1, 1);

        doubleSpinBoxDI1 = new QDoubleSpinBox(SettingTriggerSetting);
        doubleSpinBoxDI1->setObjectName(QStringLiteral("doubleSpinBoxDI1"));
        sizePolicy1.setHeightForWidth(doubleSpinBoxDI1->sizePolicy().hasHeightForWidth());
        doubleSpinBoxDI1->setSizePolicy(sizePolicy1);
        doubleSpinBoxDI1->setMinimumSize(QSize(120, 40));
        doubleSpinBoxDI1->setMaximumSize(QSize(120, 40));
        doubleSpinBoxDI1->setStyleSheet(QStringLiteral(""));
        doubleSpinBoxDI1->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        doubleSpinBoxDI1->setDecimals(1);
        doubleSpinBoxDI1->setMinimum(0);
        doubleSpinBoxDI1->setMaximum(24);
        doubleSpinBoxDI1->setSingleStep(0.1);
        doubleSpinBoxDI1->setValue(0);

        gridLayout->addWidget(doubleSpinBoxDI1, 2, 2, 1, 2);

        doubleSpinBoxDI4 = new QDoubleSpinBox(SettingTriggerSetting);
        doubleSpinBoxDI4->setObjectName(QStringLiteral("doubleSpinBoxDI4"));
        sizePolicy1.setHeightForWidth(doubleSpinBoxDI4->sizePolicy().hasHeightForWidth());
        doubleSpinBoxDI4->setSizePolicy(sizePolicy1);
        doubleSpinBoxDI4->setMinimumSize(QSize(120, 40));
        doubleSpinBoxDI4->setMaximumSize(QSize(120, 40));
        doubleSpinBoxDI4->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        doubleSpinBoxDI4->setDecimals(1);
        doubleSpinBoxDI4->setMaximum(24);
        doubleSpinBoxDI4->setSingleStep(0.1);
        doubleSpinBoxDI4->setValue(0);

        gridLayout->addWidget(doubleSpinBoxDI4, 5, 2, 1, 2);

        doubleSpinBoxAI1 = new QDoubleSpinBox(SettingTriggerSetting);
        doubleSpinBoxAI1->setObjectName(QStringLiteral("doubleSpinBoxAI1"));
        sizePolicy1.setHeightForWidth(doubleSpinBoxAI1->sizePolicy().hasHeightForWidth());
        doubleSpinBoxAI1->setSizePolicy(sizePolicy1);
        doubleSpinBoxAI1->setMinimumSize(QSize(120, 40));
        doubleSpinBoxAI1->setMaximumSize(QSize(120, 40));
        doubleSpinBoxAI1->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        doubleSpinBoxAI1->setDecimals(1);
        doubleSpinBoxAI1->setMaximum(30);
        doubleSpinBoxAI1->setSingleStep(0.1);
        doubleSpinBoxAI1->setValue(0);

        gridLayout->addWidget(doubleSpinBoxAI1, 6, 2, 1, 2);

        pushButtonRangeDI3 = new QPushButton(SettingTriggerSetting);
        pushButtonRangeDI3->setObjectName(QStringLiteral("pushButtonRangeDI3"));
        sizePolicy1.setHeightForWidth(pushButtonRangeDI3->sizePolicy().hasHeightForWidth());
        pushButtonRangeDI3->setSizePolicy(sizePolicy1);
        pushButtonRangeDI3->setMinimumSize(QSize(60, 40));
        pushButtonRangeDI3->setMaximumSize(QSize(60, 40));
        pushButtonRangeDI3->setAutoFillBackground(true);
        pushButtonRangeDI3->setIconSize(QSize(10, 10));

        gridLayout->addWidget(pushButtonRangeDI3, 4, 1, 1, 1);

        pushButtonRangeDI4 = new QPushButton(SettingTriggerSetting);
        pushButtonRangeDI4->setObjectName(QStringLiteral("pushButtonRangeDI4"));
        sizePolicy1.setHeightForWidth(pushButtonRangeDI4->sizePolicy().hasHeightForWidth());
        pushButtonRangeDI4->setSizePolicy(sizePolicy1);
        pushButtonRangeDI4->setMinimumSize(QSize(60, 40));
        pushButtonRangeDI4->setMaximumSize(QSize(60, 40));
        pushButtonRangeDI4->setAutoFillBackground(true);
        pushButtonRangeDI4->setIconSize(QSize(10, 10));

        gridLayout->addWidget(pushButtonRangeDI4, 5, 1, 1, 1);

        pushButtonRangeDI1 = new QPushButton(SettingTriggerSetting);
        pushButtonRangeDI1->setObjectName(QStringLiteral("pushButtonRangeDI1"));
        pushButtonRangeDI1->setEnabled(true);
        sizePolicy1.setHeightForWidth(pushButtonRangeDI1->sizePolicy().hasHeightForWidth());
        pushButtonRangeDI1->setSizePolicy(sizePolicy1);
        pushButtonRangeDI1->setMinimumSize(QSize(60, 40));
        pushButtonRangeDI1->setMaximumSize(QSize(60, 40));
        pushButtonRangeDI1->setAutoFillBackground(true);
        pushButtonRangeDI1->setStyleSheet(QStringLiteral(""));
        pushButtonRangeDI1->setIconSize(QSize(10, 10));

        gridLayout->addWidget(pushButtonRangeDI1, 2, 1, 1, 1);

        doubleSpinBoxDI2 = new QDoubleSpinBox(SettingTriggerSetting);
        doubleSpinBoxDI2->setObjectName(QStringLiteral("doubleSpinBoxDI2"));
        sizePolicy1.setHeightForWidth(doubleSpinBoxDI2->sizePolicy().hasHeightForWidth());
        doubleSpinBoxDI2->setSizePolicy(sizePolicy1);
        doubleSpinBoxDI2->setMinimumSize(QSize(120, 40));
        doubleSpinBoxDI2->setMaximumSize(QSize(120, 40));
        doubleSpinBoxDI2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        doubleSpinBoxDI2->setDecimals(1);
        doubleSpinBoxDI2->setMaximum(24);
        doubleSpinBoxDI2->setSingleStep(0.1);
        doubleSpinBoxDI2->setValue(0);

        gridLayout->addWidget(doubleSpinBoxDI2, 3, 2, 1, 2);

        pushButtonRangeDI2 = new QPushButton(SettingTriggerSetting);
        pushButtonRangeDI2->setObjectName(QStringLiteral("pushButtonRangeDI2"));
        sizePolicy1.setHeightForWidth(pushButtonRangeDI2->sizePolicy().hasHeightForWidth());
        pushButtonRangeDI2->setSizePolicy(sizePolicy1);
        pushButtonRangeDI2->setMinimumSize(QSize(60, 40));
        pushButtonRangeDI2->setMaximumSize(QSize(60, 40));
        pushButtonRangeDI2->setAutoFillBackground(true);
        pushButtonRangeDI2->setIconSize(QSize(10, 10));

        gridLayout->addWidget(pushButtonRangeDI2, 3, 1, 1, 1);

        doubleSpinBoxAI2 = new QDoubleSpinBox(SettingTriggerSetting);
        doubleSpinBoxAI2->setObjectName(QStringLiteral("doubleSpinBoxAI2"));
        sizePolicy1.setHeightForWidth(doubleSpinBoxAI2->sizePolicy().hasHeightForWidth());
        doubleSpinBoxAI2->setSizePolicy(sizePolicy1);
        doubleSpinBoxAI2->setMinimumSize(QSize(120, 40));
        doubleSpinBoxAI2->setMaximumSize(QSize(120, 40));
        doubleSpinBoxAI2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);
        doubleSpinBoxAI2->setDecimals(1);
        doubleSpinBoxAI2->setMinimum(0);
        doubleSpinBoxAI2->setMaximum(30);
        doubleSpinBoxAI2->setSingleStep(0.1);
        doubleSpinBoxAI2->setValue(0);

        gridLayout->addWidget(doubleSpinBoxAI2, 7, 2, 1, 2);

        pushButtonRangeAI3 = new QPushButton(SettingTriggerSetting);
        pushButtonRangeAI3->setObjectName(QStringLiteral("pushButtonRangeAI3"));
        sizePolicy1.setHeightForWidth(pushButtonRangeAI3->sizePolicy().hasHeightForWidth());
        pushButtonRangeAI3->setSizePolicy(sizePolicy1);
        pushButtonRangeAI3->setMinimumSize(QSize(60, 40));
        pushButtonRangeAI3->setMaximumSize(QSize(60, 40));
        pushButtonRangeAI3->setAutoFillBackground(true);
        pushButtonRangeAI3->setIconSize(QSize(10, 10));

        gridLayout->addWidget(pushButtonRangeAI3, 9, 1, 1, 1);

        labelAI3 = new QLabel(SettingTriggerSetting);
        labelAI3->setObjectName(QStringLiteral("labelAI3"));
        sizePolicy1.setHeightForWidth(labelAI3->sizePolicy().hasHeightForWidth());
        labelAI3->setSizePolicy(sizePolicy1);
        labelAI3->setMinimumSize(QSize(40, 40));
        labelAI3->setMaximumSize(QSize(40, 40));
        labelAI3->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(labelAI3, 9, 0, 1, 1);

        labelTitleTriggerSetting = new QLabel(SettingTriggerSetting);
        labelTitleTriggerSetting->setObjectName(QStringLiteral("labelTitleTriggerSetting"));
        QSizePolicy sizePolicy3(QSizePolicy::Expanding, QSizePolicy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(labelTitleTriggerSetting->sizePolicy().hasHeightForWidth());
        labelTitleTriggerSetting->setSizePolicy(sizePolicy3);
        labelTitleTriggerSetting->setMinimumSize(QSize(0, 40));
        QFont font1;
        font1.setPointSize(12);
        labelTitleTriggerSetting->setFont(font1);
        labelTitleTriggerSetting->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(labelTitleTriggerSetting, 0, 0, 1, 7);

        pushButtonRangeAI1 = new QPushButton(SettingTriggerSetting);
        pushButtonRangeAI1->setObjectName(QStringLiteral("pushButtonRangeAI1"));
        sizePolicy1.setHeightForWidth(pushButtonRangeAI1->sizePolicy().hasHeightForWidth());
        pushButtonRangeAI1->setSizePolicy(sizePolicy1);
        pushButtonRangeAI1->setMinimumSize(QSize(60, 40));
        pushButtonRangeAI1->setMaximumSize(QSize(60, 40));
        pushButtonRangeAI1->setAutoFillBackground(true);
        pushButtonRangeAI1->setIconSize(QSize(10, 10));

        gridLayout->addWidget(pushButtonRangeAI1, 6, 1, 1, 1);

        labelAI2 = new QLabel(SettingTriggerSetting);
        labelAI2->setObjectName(QStringLiteral("labelAI2"));
        sizePolicy1.setHeightForWidth(labelAI2->sizePolicy().hasHeightForWidth());
        labelAI2->setSizePolicy(sizePolicy1);
        labelAI2->setMinimumSize(QSize(40, 40));
        labelAI2->setMaximumSize(QSize(40, 40));
        labelAI2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(labelAI2, 7, 0, 1, 1);

        labelLevel = new QLabel(SettingTriggerSetting);
        labelLevel->setObjectName(QStringLiteral("labelLevel"));
        sizePolicy2.setHeightForWidth(labelLevel->sizePolicy().hasHeightForWidth());
        labelLevel->setSizePolicy(sizePolicy2);
        labelLevel->setMinimumSize(QSize(40, 40));
        labelLevel->setMaximumSize(QSize(120, 16777215));
        labelLevel->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(labelLevel, 1, 2, 1, 1);

        labelDI3 = new QLabel(SettingTriggerSetting);
        labelDI3->setObjectName(QStringLiteral("labelDI3"));
        sizePolicy1.setHeightForWidth(labelDI3->sizePolicy().hasHeightForWidth());
        labelDI3->setSizePolicy(sizePolicy1);
        labelDI3->setMinimumSize(QSize(40, 40));
        labelDI3->setMaximumSize(QSize(40, 40));
        labelDI3->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(labelDI3, 4, 0, 1, 1);

        labelDI2 = new QLabel(SettingTriggerSetting);
        labelDI2->setObjectName(QStringLiteral("labelDI2"));
        sizePolicy1.setHeightForWidth(labelDI2->sizePolicy().hasHeightForWidth());
        labelDI2->setSizePolicy(sizePolicy1);
        labelDI2->setMinimumSize(QSize(40, 40));
        labelDI2->setMaximumSize(QSize(40, 40));
        labelDI2->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(labelDI2, 3, 0, 1, 1);

        labelDI4 = new QLabel(SettingTriggerSetting);
        labelDI4->setObjectName(QStringLiteral("labelDI4"));
        sizePolicy1.setHeightForWidth(labelDI4->sizePolicy().hasHeightForWidth());
        labelDI4->setSizePolicy(sizePolicy1);
        labelDI4->setMinimumSize(QSize(40, 40));
        labelDI4->setMaximumSize(QSize(40, 40));
        labelDI4->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(labelDI4, 5, 0, 1, 1);

        pushButtonRangeAI2 = new QPushButton(SettingTriggerSetting);
        pushButtonRangeAI2->setObjectName(QStringLiteral("pushButtonRangeAI2"));
        sizePolicy1.setHeightForWidth(pushButtonRangeAI2->sizePolicy().hasHeightForWidth());
        pushButtonRangeAI2->setSizePolicy(sizePolicy1);
        pushButtonRangeAI2->setMinimumSize(QSize(60, 40));
        pushButtonRangeAI2->setMaximumSize(QSize(60, 40));
        pushButtonRangeAI2->setAutoFillBackground(true);
        pushButtonRangeAI2->setIconSize(QSize(10, 10));

        gridLayout->addWidget(pushButtonRangeAI2, 7, 1, 1, 1);

        labelDI1 = new QLabel(SettingTriggerSetting);
        labelDI1->setObjectName(QStringLiteral("labelDI1"));
        sizePolicy1.setHeightForWidth(labelDI1->sizePolicy().hasHeightForWidth());
        labelDI1->setSizePolicy(sizePolicy1);
        labelDI1->setMinimumSize(QSize(40, 40));
        labelDI1->setMaximumSize(QSize(40, 40));
        labelDI1->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(labelDI1, 2, 0, 1, 1);

        labelAI1 = new QLabel(SettingTriggerSetting);
        labelAI1->setObjectName(QStringLiteral("labelAI1"));
        sizePolicy1.setHeightForWidth(labelAI1->sizePolicy().hasHeightForWidth());
        labelAI1->setSizePolicy(sizePolicy1);
        labelAI1->setMinimumSize(QSize(40, 40));
        labelAI1->setMaximumSize(QSize(40, 40));
        labelAI1->setAlignment(Qt::AlignRight|Qt::AlignTrailing|Qt::AlignVCenter);

        gridLayout->addWidget(labelAI1, 6, 0, 1, 1);

        pushButtonEdgeDI1 = new QPushButton(SettingTriggerSetting);
        pushButtonEdgeDI1->setObjectName(QStringLiteral("pushButtonEdgeDI1"));
        sizePolicy1.setHeightForWidth(pushButtonEdgeDI1->sizePolicy().hasHeightForWidth());
        pushButtonEdgeDI1->setSizePolicy(sizePolicy1);
        pushButtonEdgeDI1->setMinimumSize(QSize(40, 40));
        pushButtonEdgeDI1->setMaximumSize(QSize(40, 40));
        pushButtonEdgeDI1->setAutoFillBackground(true);
        pushButtonEdgeDI1->setStyleSheet(QStringLiteral(""));
        pushButtonEdgeDI1->setIconSize(QSize(10, 10));

        gridLayout->addWidget(pushButtonEdgeDI1, 2, 4, 1, 1);

        pushButtonEdgeDI2 = new QPushButton(SettingTriggerSetting);
        pushButtonEdgeDI2->setObjectName(QStringLiteral("pushButtonEdgeDI2"));
        sizePolicy1.setHeightForWidth(pushButtonEdgeDI2->sizePolicy().hasHeightForWidth());
        pushButtonEdgeDI2->setSizePolicy(sizePolicy1);
        pushButtonEdgeDI2->setMinimumSize(QSize(40, 40));
        pushButtonEdgeDI2->setMaximumSize(QSize(40, 40));
        pushButtonEdgeDI2->setAutoFillBackground(true);
        pushButtonEdgeDI2->setIconSize(QSize(10, 10));

        gridLayout->addWidget(pushButtonEdgeDI2, 3, 4, 1, 1);

        pushButtonEdgeDI3 = new QPushButton(SettingTriggerSetting);
        pushButtonEdgeDI3->setObjectName(QStringLiteral("pushButtonEdgeDI3"));
        sizePolicy1.setHeightForWidth(pushButtonEdgeDI3->sizePolicy().hasHeightForWidth());
        pushButtonEdgeDI3->setSizePolicy(sizePolicy1);
        pushButtonEdgeDI3->setMinimumSize(QSize(40, 40));
        pushButtonEdgeDI3->setMaximumSize(QSize(40, 40));
        pushButtonEdgeDI3->setAutoFillBackground(true);
        pushButtonEdgeDI3->setIconSize(QSize(10, 10));

        gridLayout->addWidget(pushButtonEdgeDI3, 4, 4, 1, 1);

        pushButtonEdgeDI4 = new QPushButton(SettingTriggerSetting);
        pushButtonEdgeDI4->setObjectName(QStringLiteral("pushButtonEdgeDI4"));
        sizePolicy1.setHeightForWidth(pushButtonEdgeDI4->sizePolicy().hasHeightForWidth());
        pushButtonEdgeDI4->setSizePolicy(sizePolicy1);
        pushButtonEdgeDI4->setMinimumSize(QSize(40, 40));
        pushButtonEdgeDI4->setMaximumSize(QSize(40, 40));
        pushButtonEdgeDI4->setAutoFillBackground(true);
        pushButtonEdgeDI4->setIconSize(QSize(10, 10));

        gridLayout->addWidget(pushButtonEdgeDI4, 5, 4, 1, 1);

        pushButtonEdgeAI1 = new QPushButton(SettingTriggerSetting);
        pushButtonEdgeAI1->setObjectName(QStringLiteral("pushButtonEdgeAI1"));
        sizePolicy1.setHeightForWidth(pushButtonEdgeAI1->sizePolicy().hasHeightForWidth());
        pushButtonEdgeAI1->setSizePolicy(sizePolicy1);
        pushButtonEdgeAI1->setMinimumSize(QSize(40, 40));
        pushButtonEdgeAI1->setMaximumSize(QSize(40, 40));
        pushButtonEdgeAI1->setAutoFillBackground(true);
        pushButtonEdgeAI1->setIconSize(QSize(10, 10));

        gridLayout->addWidget(pushButtonEdgeAI1, 6, 4, 1, 1);

        pushButtonEdgeAI2 = new QPushButton(SettingTriggerSetting);
        pushButtonEdgeAI2->setObjectName(QStringLiteral("pushButtonEdgeAI2"));
        sizePolicy1.setHeightForWidth(pushButtonEdgeAI2->sizePolicy().hasHeightForWidth());
        pushButtonEdgeAI2->setSizePolicy(sizePolicy1);
        pushButtonEdgeAI2->setMinimumSize(QSize(40, 40));
        pushButtonEdgeAI2->setMaximumSize(QSize(40, 40));
        pushButtonEdgeAI2->setAutoFillBackground(true);
        pushButtonEdgeAI2->setIconSize(QSize(10, 10));

        gridLayout->addWidget(pushButtonEdgeAI2, 7, 4, 1, 1);

        labelEdge = new QLabel(SettingTriggerSetting);
        labelEdge->setObjectName(QStringLiteral("labelEdge"));
        QSizePolicy sizePolicy4(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy4.setHorizontalStretch(0);
        sizePolicy4.setVerticalStretch(30);
        sizePolicy4.setHeightForWidth(labelEdge->sizePolicy().hasHeightForWidth());
        labelEdge->setSizePolicy(sizePolicy4);
        labelEdge->setMinimumSize(QSize(40, 40));
        labelEdge->setAlignment(Qt::AlignCenter);

        gridLayout->addWidget(labelEdge, 1, 4, 1, 1);

        pushButtonRangeAI2->raise();
        labelTitleTriggerSetting->raise();
        labelRange->raise();
        labelLevel->raise();
        labelDI1->raise();
        labelDI2->raise();
        labelDI3->raise();
        labelDI4->raise();
        labelAI1->raise();
        labelAI2->raise();
        pushButtonRangeDI2->raise();
        pushButtonRangeDI3->raise();
        pushButtonRangeDI4->raise();
        pushButtonRangeAI1->raise();
        labelAI3->raise();
        pushButtonRangeAI3->raise();
        pushButtonRangeDI1->raise();
        doubleSpinBoxDI2->raise();
        doubleSpinBoxAI2->raise();
        doubleSpinBoxDI3->raise();
        doubleSpinBoxDI1->raise();
        doubleSpinBoxAI1->raise();
        doubleSpinBoxDI4->raise();
        labelAI4->raise();
        pushButtonRangeAI4->raise();
        pushButtonEdgeDI1->raise();
        pushButtonEdgeDI2->raise();
        pushButtonEdgeDI3->raise();
        pushButtonEdgeDI4->raise();
        pushButtonEdgeAI1->raise();
        pushButtonEdgeAI2->raise();
        labelEdge->raise();

        retranslateUi(SettingTriggerSetting);

        QMetaObject::connectSlotsByName(SettingTriggerSetting);
    } // setupUi

    void retranslateUi(QFrame *SettingTriggerSetting)
    {
        SettingTriggerSetting->setWindowTitle(QApplication::translate("SettingTriggerSetting", "Form", 0));
        labelAI4->setText(QApplication::translate("SettingTriggerSetting", "AI 4", 0));
        labelRange->setText(QApplication::translate("SettingTriggerSetting", "Range [V]", 0));
        pushButtonRangeAI4->setText(QString());
        pushButtonRangeDI3->setText(QString());
        pushButtonRangeDI4->setText(QString());
        pushButtonRangeDI1->setText(QString());
        pushButtonRangeDI2->setText(QString());
        pushButtonRangeAI3->setText(QString());
        labelAI3->setText(QApplication::translate("SettingTriggerSetting", "AI 3", 0));
        labelTitleTriggerSetting->setText(QApplication::translate("SettingTriggerSetting", "Trigger setting", 0));
        pushButtonRangeAI1->setText(QString());
        labelAI2->setText(QApplication::translate("SettingTriggerSetting", "AI 2", 0));
        labelLevel->setText(QApplication::translate("SettingTriggerSetting", "Level [V]", 0));
        labelDI3->setText(QApplication::translate("SettingTriggerSetting", "DI 3", 0));
        labelDI2->setText(QApplication::translate("SettingTriggerSetting", "DI 2", 0));
        labelDI4->setText(QApplication::translate("SettingTriggerSetting", "DI 4", 0));
        pushButtonRangeAI2->setText(QString());
        labelDI1->setText(QApplication::translate("SettingTriggerSetting", "DI 1", 0));
        labelAI1->setText(QApplication::translate("SettingTriggerSetting", "AI 1", 0));
        pushButtonEdgeDI1->setText(QString());
        pushButtonEdgeDI2->setText(QString());
        pushButtonEdgeDI3->setText(QString());
        pushButtonEdgeDI4->setText(QString());
        pushButtonEdgeAI1->setText(QString());
        pushButtonEdgeAI2->setText(QString());
        labelEdge->setText(QApplication::translate("SettingTriggerSetting", "Edge", 0));
    } // retranslateUi

};

namespace Ui {
    class SettingTriggerSetting: public Ui_SettingTriggerSetting {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SETTINGTRIGGERSETTING_H
