/********************************************************************************
** Form generated from reading UI file 'settingWindow.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_SETTINGWINDOW_H
#define UI_SETTINGWINDOW_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "settingChannelSelection.h"
#include "settingPreTriggerPercentage.h"
#include "settingTimeScaleFactor.h"
#include "settingTriggerFunction.h"
#include "settingTriggerSetting.h"

QT_BEGIN_NAMESPACE

class Ui_SettingWindow
{
public:
    QHBoxLayout *horizontalLayout;
    QVBoxLayout *verticalLayoutLeft;
    SettingChannelSelection *widgetChannelSelection;
    SettingTimeScaleFactor *widgetTimeScaleFactor;
    SettingPreTriggerPercentage *widgetPreTriggerPercentage;
    QVBoxLayout *verticalLayoutRight;
    SettingTriggerSetting *widgetTriggerSetting;
    SettingTriggerFunction *widgetTriggerFunction;

    void setupUi(QWidget *SettingWindow)
    {
        if (SettingWindow->objectName().isEmpty())
            SettingWindow->setObjectName(QStringLiteral("SettingWindow"));
        SettingWindow->resize(900, 500);
        horizontalLayout = new QHBoxLayout(SettingWindow);
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        verticalLayoutLeft = new QVBoxLayout();
        verticalLayoutLeft->setObjectName(QStringLiteral("verticalLayoutLeft"));
        widgetChannelSelection = new SettingChannelSelection(SettingWindow);
        widgetChannelSelection->setObjectName(QStringLiteral("widgetChannelSelection"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(widgetChannelSelection->sizePolicy().hasHeightForWidth());
        widgetChannelSelection->setSizePolicy(sizePolicy);

        verticalLayoutLeft->addWidget(widgetChannelSelection);

        widgetTimeScaleFactor = new SettingTimeScaleFactor(SettingWindow);
        widgetTimeScaleFactor->setObjectName(QStringLiteral("widgetTimeScaleFactor"));
        sizePolicy.setHeightForWidth(widgetTimeScaleFactor->sizePolicy().hasHeightForWidth());
        widgetTimeScaleFactor->setSizePolicy(sizePolicy);

        verticalLayoutLeft->addWidget(widgetTimeScaleFactor);

        widgetPreTriggerPercentage = new SettingPreTriggerPercentage(SettingWindow);
        widgetPreTriggerPercentage->setObjectName(QStringLiteral("widgetPreTriggerPercentage"));
        sizePolicy.setHeightForWidth(widgetPreTriggerPercentage->sizePolicy().hasHeightForWidth());
        widgetPreTriggerPercentage->setSizePolicy(sizePolicy);

        verticalLayoutLeft->addWidget(widgetPreTriggerPercentage);


        horizontalLayout->addLayout(verticalLayoutLeft);

        verticalLayoutRight = new QVBoxLayout();
        verticalLayoutRight->setObjectName(QStringLiteral("verticalLayoutRight"));
        widgetTriggerSetting = new SettingTriggerSetting(SettingWindow);
        widgetTriggerSetting->setObjectName(QStringLiteral("widgetTriggerSetting"));
        sizePolicy.setHeightForWidth(widgetTriggerSetting->sizePolicy().hasHeightForWidth());
        widgetTriggerSetting->setSizePolicy(sizePolicy);

        verticalLayoutRight->addWidget(widgetTriggerSetting);

        widgetTriggerFunction = new SettingTriggerFunction(SettingWindow);
        widgetTriggerFunction->setObjectName(QStringLiteral("widgetTriggerFunction"));
        sizePolicy.setHeightForWidth(widgetTriggerFunction->sizePolicy().hasHeightForWidth());
        widgetTriggerFunction->setSizePolicy(sizePolicy);

        verticalLayoutRight->addWidget(widgetTriggerFunction);


        horizontalLayout->addLayout(verticalLayoutRight);


        retranslateUi(SettingWindow);

        QMetaObject::connectSlotsByName(SettingWindow);
    } // setupUi

    void retranslateUi(QWidget *SettingWindow)
    {
        SettingWindow->setWindowTitle(QApplication::translate("SettingWindow", "Form", 0));
    } // retranslateUi

};

namespace Ui {
    class SettingWindow: public Ui_SettingWindow {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_SETTINGWINDOW_H
