/********************************************************************************
** Form generated from reading UI file 'stateFrame.ui'
**
** Created by: Qt User Interface Compiler version 5.3.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_STATEFRAME_H
#define UI_STATEFRAME_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QFrame>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_StateFrame
{
public:
    QGridLayout *gridLayout;
    QFrame *frame;
    QVBoxLayout *verticalLayout;
    QHBoxLayout *horizontalLayout;
    QSpacerItem *horizontalSpacer;
    QLabel *labelLogoState;
    QLabel *labelState;

    void setupUi(QWidget *StateFrame)
    {
        if (StateFrame->objectName().isEmpty())
            StateFrame->setObjectName(QStringLiteral("StateFrame"));
        StateFrame->resize(179, 88);
        gridLayout = new QGridLayout(StateFrame);
        gridLayout->setObjectName(QStringLiteral("gridLayout"));
        gridLayout->setContentsMargins(0, 0, 0, 0);
        frame = new QFrame(StateFrame);
        frame->setObjectName(QStringLiteral("frame"));
        frame->setFrameShape(QFrame::Panel);
        verticalLayout = new QVBoxLayout(frame);
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        verticalLayout->setContentsMargins(0, 0, 0, 0);
        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        horizontalSpacer = new QSpacerItem(5, 20, QSizePolicy::Fixed, QSizePolicy::Minimum);

        horizontalLayout->addItem(horizontalSpacer);

        labelLogoState = new QLabel(frame);
        labelLogoState->setObjectName(QStringLiteral("labelLogoState"));
        labelLogoState->setMinimumSize(QSize(33, 33));
        labelLogoState->setMaximumSize(QSize(33, 33));
        labelLogoState->setScaledContents(true);
        labelLogoState->setMargin(5);

        horizontalLayout->addWidget(labelLogoState);

        labelState = new QLabel(frame);
        labelState->setObjectName(QStringLiteral("labelState"));
        QSizePolicy sizePolicy(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(labelState->sizePolicy().hasHeightForWidth());
        labelState->setSizePolicy(sizePolicy);
        labelState->setMinimumSize(QSize(0, 0));
        labelState->setMaximumSize(QSize(16777215, 16777215));
        QFont font;
        font.setPointSize(16);
        font.setBold(true);
        font.setWeight(75);
        labelState->setFont(font);
        labelState->setAlignment(Qt::AlignCenter);

        horizontalLayout->addWidget(labelState);


        verticalLayout->addLayout(horizontalLayout);


        gridLayout->addWidget(frame, 0, 0, 1, 1);


        retranslateUi(StateFrame);

        QMetaObject::connectSlotsByName(StateFrame);
    } // setupUi

    void retranslateUi(QWidget *StateFrame)
    {
        StateFrame->setWindowTitle(QApplication::translate("StateFrame", "Form", 0));
        labelLogoState->setText(QString());
        labelState->setText(QApplication::translate("StateFrame", "unknow", 0));
    } // retranslateUi

};

namespace Ui {
    class StateFrame: public Ui_StateFrame {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_STATEFRAME_H
